# 04. KUBERNETES

## Architecture — 84 questions

1. whats the difference between docker and kubernetes
2. Explain  kubernetes Architecture and component and their uses.
3. How Kubernetes handles service discovery can you explain .
4. Updating worker nodes in k8s
5. K8s architecture
6. Purpose of scheduler in k8s
7. How to find orphan resources in kubernetes and remove it?
8. architecture of Kubernetes
9. Different types of services in Kubernetes.
10. Explain the upgrade process for a Kubernetes cluster with zero downtime.
11. What is the major issue that you resolved in Kubernetes
12. what are name spaces in k8s
13. Explain the Kubernetes architecture and how it works.
14. What is a Service in Kubernetes?
15. Explain Kubernetes architecture
16. nodes and pods?
17. can we run 1 conatiner with 2 pods
18. An init container comes up with the Kubernetes cluster ✅ (kubernetes)
19. Taint and toleration in Kubernetes what it is ❌ (kubernetes)
20. Compute reservation in manifest files ❌ (kubernetes)
21. If you type kubectl get pods, what will happen in the backend.
22. How do pods interact with each other?
23. How you are taking backup kubernetes .
24. How many pods do you manage
25. Explain k8s architecture
26. What do you work on k8s
27. Type of services in Kubernetes, give their use case
28. Kubernetes:
29. how did u manage Kubernetes pods it is on Linux right?
30. Custom resource in k8s
31. Upgrading the worker nodes in K8s
32. For junior team member, what are the roles will be provided in k8s
33. While updating your worker node, you're trying to perform drain out the PODs  but some PODs are not removed from the node, what you will do
34. I've two PODS in the same worker node, will they communicate with each other?
35. I've two PODS in diff worker nodes, can they communicate ?
36. Docker Swarm/Kubernetes
37. What's the purpose of using init containers in K8s
38. How do you give access to the user for a namespace in kubernetes cluster
39. What are the kubernetes resources you know
40. Kubernetes architecture in depth. Every component functioning. How would you join a new node to control plane?
41. Like kubelet is there any similar agent used to manage the control plane side of things?
42. How would you implement security for Kubernetes(both on container side and the infra side using native Kubernetes solutions)
43. Have u done k8s cluster upgrade
44. u r unable to evict the pods from node, how to resolve
45. what is kubernetes operator? If I need to run a shell script before any container to start how can i do it using operator ?
46. What is the extra component/service present in Managed k8s cluster in cloud
47. if there are multiple pods, how do they identify each other ?
48. What errors you faced when you're working with k8s
49. K8s architecture and argocd  architecture
50. Pods fail to schedule
51. What are the different ways to specify the probes in Kubernetes?
52. About Kubernetes architecture
53. What is the stateful set in the Kubernetes?
54. Commands used for Kubernetes,Docker and Ansible..
55. Explain Kubernetes Structure, Config Map and Schedular..
56. K8s Architecture.
57. How do you upgrage k8s cluster.
58. What is hierarchy of Kubernetes?
59. Kubernetes cluster upgrade from one version to another version? What is the approach?
60. What is PDP in Kubernetes?
61. K8s command to list the pods with specific nodes?
62. In which way are you managing your cluster — using kubectl commands or something else?
63. If your cluster is in a private subnet, then outside kubectl will not be working, right? How are you accessing that?
64. What is EBS and EFS in Kubernetes?
65. K8s backup policies
66. How to limit the resource usage in K8s
67. Have you integrated Global LB with K8s cluster
68. How would you design a Kubernetes cluster that must survive a full AZ failure without data loss, while running stateful workloads at scale?
69. How do you bootstrap kubectl access?
70. Q6. If your teammate also wants access to the same cluster through kubectl, what steps do you follow?
71. Q7. In which Kubernetes resource do you map IAM users/roles?
72. What happens to old pods?
73. Is rollback handled by CI/CD or Kubernetes?
74. How will take a backup of K8s clusters regularly
75. Tell me about  Docker Compose and Kubernetes ?
76. How does Kubernetes work — how do the master and worker nodes communicate, and what runs inside them?
77. What is the command for rolling back to a specific revision in Kubernetes?
78. What types of services exist in Kubernetes, apart from ClusterIP, NodePort, and LoadBalancer?
79. am having some min max pods running, suppose on festival day traffic increases at that time I have to increase pods, when no traffic is there I have reduce the pods, how will you achieve it in K8
80. When designing a microservices-oriented infrastructure, what technologies and components (like load balancer, service mesh, Kubernetes) would you bring in, and how would you design the estate?
81. When kubernetes node fails what will happen.
82. Two pods which are part of same replica set are not able to communicate with each other what may be the reason
83. How to handle the extra traffic coming onto pods? Which solution you can implement
84. Why k8s is need if docker volume is there? (Dont remember exact Q framing but sounded like this)

## Pods — 48 questions

1. Object used to manage kubernetes cluster and ensure pod always has specific resources
2. Question : Considering you have different environments and you have one application or which is microservice which is finally going to get deployed into one of the pod in GKE,
3. 11 . Can pod be scheduled if have below security constent .
4. If DB POD is down, will it affect the data it gets stored,
5. How about the sticky session data if POD gets down → Yes the session data will be lost,
6. How to assign memory to pod and how to make sure if pod should not get memory constraint. What to do if it happens.
7. In a multi-cloud environment, if you want to block a pod to go into a particular node, how would you do it?
8. Jenkins pipeline setup Kubernetes If a pod is getting restarted constantly, what steps are you going to follow?
9. What is the command to access a pod and how can you define or create a Kubernetes class or object?
10. Pod disruption budget
11. How does Pod-to-Pod communication work?
12. What is a Pod Disruption Budget?
13. Can I run POD inside master-node itself?,
14. limits of 4 vCPU / 16 GB and requests of 2 vCPU / 10 GB RAM, how many instances of the pod will
15. Suppose you have  in satetfull 3 pods which having name mongo-0 , mongo-1, mongo-2 what happen if mongo-0 dies when new pod will create what will be pod new name ?
16. How to check the kubectl logs of a POD before it restarted
17. What is pod
18. What is pod affinity
19. Can we use POD as an agent? What are the drawbacks if we do so?
20. how to shecedlue a pod in specifc node
21. How do you handle when pod dies
22. can we delete pod and multipilte container can run in
23. Pod Distribution budget in k8s
24. When you're trying to deploy a POD, it's  throwing an error, how will you investigate.
25. How to deploy a POD into a certain NODE?
26. Pod is running fine, all the parameters looks good, but the traffic is not reaching the pod when the user is trying to access the application, what could be the possible reason ?
27. Pod to pod communication
28. How many containers can run in a pod?
29. in ur projects how many containers u ran? can u give me the use case where can run 4-5 containers in a pod?
30. Pod Affinity and Node Affinity.
31. How do you ensure POD to POD communication?
32. You’re trying to schedule a new POD but the new PODs are not deploying properly, what checks will be done.
33. I have an S3 bucket, and there is some file inside it — my pod wants to access that S3 bucket. How will it access it?
34. *It should've a ReadinessProbe which executes the command 'stat /tmp/ready' . This means once the file exists the Pod should be ready.
35. As a Devops engineer , you have to make a decision according to best and optimized solution for each component that you decide, like - should the db be run as statefullset or RDS/any cloud db managed solution is better, how do we deploy frontend-whether as pod or S3+cloudfront etc.
36. How do you debug intermittent pod restarts when liveness probes pass, readiness passes, but the pod is still killed by the node?
37. Q14. What is a Pod Disruption Budget (PDB)?
38. Check pod replicas?
39. How will you investigate POD failure
40. In k8s architecture which component is not running as pod
41. what is node affinity and pod affinity  in K8
42. In pod configuration what we should do from Production perspective
43. Calico and VPC CNI plugin difference. Why one is preferred over other. How would they help in setting up networking for pod.
44. How is an ip address allocate to a pod. Does CNI plugin use same CIDR range which is provided by VPC or different?
45. There are 3 backend pods in 3 different region. If one pod goes down how would the request be managed
46. A backend pod needs to interact with S3 and lambda. How would you achieve it
47. A replica set has 3 pods. One pod is not coming up. What maybe be the reason
48. If 2 pod are in diff namespace then how can we make them communicate to each other securely?

## ReplicaSet — 0 questions

_No matching repository questions in the uploaded material._

## Deployment — 22 questions

1. Question : You have optimized Kubernetes deployment configs. So can you explain me what have what was the role and what what have you done there?
2. Limiting the resource usage in k8s not through deployment.yam → Through namespace
3. what is difference between deployment and statefulset
4. Asked about k8s ( deployment, services, and configs)
5. What is a Deployment in Kubernetes?
6. suppose we have pods 2 running in rolling updates some are in deployments set and some pods are in statefull set , how rolling updates strategy will work here  ?
7. In Kubernetes, how would you configure your deployment to double CPU allocation once usage crosses 70%?
8. What are deployments, daemonset, statefulsets
9. [ ] In Kubernetes, how do you manage application deployment, scaling, and rollback? Can you walk through a specific scenario?
10. Stateful vs deployment in k8s
11. What is the difference between a Deployment and a StatefulSet in Kubernetes?
12. diff b/w Replicaset and Deployment
13. Have you worked on the Kubernetes?So what deployment strategy are you following?
14. Explain terms in deployment.yml file in kubernetes
15. Suppose a new deployment was implemented, suddenly all the PODs (new and old ones) crashed, what's the reason for this ? → New deployment exhausted the resource limit, so we need to use "limit" in our deployment.yaml file
16. You did a deployment with Canary, when you will delete the old pods, what are the KPIs to cross check before deleting them.
17. Which deployment strategy is best, assuming that you have only one POD is running
18. Why do we need a StatefulSet when we can attach a PVC to a Deployment and make it stateful?
19. If a pod is created with a Deployment and another with a StatefulSet, will the StatefulSet pod always remain on the same node?
20. If we can run MySQL with a Deployment and PVC, why do we need a StatefulSet?
21. Why does a pod created from a Deployment have two sets of random characters in its name?
22. difference between deployement and replicaset and daoemonset and statefulset (what key words you will be writing over the, for ex : deployement.yml – rolling update, canary)

## StatefulSet — 0 questions

_No matching repository questions in the uploaded material._

## DaemonSet — 2 questions

1. Difference between daemonset and state full set
2. Wat is DaemonSet in Kubernetes and what default daemons comes up with Kubernetes ✅ (kubernetes)

## Services — 0 questions

_No matching repository questions in the uploaded material._

## Ingress — 19 questions

1. How to access application if Ingress is configured but not accessible to end users, how you will resolve ?
2. Explain the complete request flow when a user accesses www.ingress.com until the request reaches the application pod.
3. What is ingress in Kubernetes
4. what is ingress controller
5. how you are setting up ingress controller
6. ELB, Ingress questions
7. What is ingress controller
8. Ingress vs Egress
9. What is ingress
10. Application is configured with Ingress but the webpage is not loading ? What are the steps will be checked
11. What is ingress and why are you using istio ?
12. Ingress vs ingress controllers
13. How can I map SSL certificates to the ingress file ?
14. What are the alternate ingress controllers you suggest as Nginx IGC is deprecated
15. Q16. During peak traffic, ingress controller is routing requests slowly. How do you debug it?
16. Check ingress controller logs?
17. Q17. Should we increase ingress controller replicas permanently or dynamically?
18. Ingress, Gateway API
19. What is ingress

## ConfigMap / Secret — 11 questions

1. •    How will the application(container/pod) fetch the latest(rotated) secrets form azure vault.
2. Where do you store application configuration and secrets? (ConfigMaps, Kubernetes Secrets, HashiCorp Vault, etc.)
3. What is a ConfigMap in Kubernetes?
4. How you are managing secrets in kubernetes
5. Configmap VS secrets
6. What are the different types of secrets in Kubernetes?
7. What is aws-auth ConfigMap?
8. → AWS Auth ConfigMap
9. What is ConfigMap and Scheduler in Kubernetes?
10. If secret is stored in vault inside a pod and that pod is down then how to tsg
11. How configmap and secrets can be used in k8s

## Storage — 8 questions

1. What is a Persistent Volume in Kubernetes?
2. Storage classes in k8s
3. What's the purpose of using storage class in k8s
4. If you are implementing HPA for statefulsets if new pod comes the pvc would be empty? How would it be able to serve the request?
5. 💾 Kubernetes Storage
6. Q13. If there is one node but multiple pods, can we use EBS for shared storage?
7. What is the difference between PV and PVC in Kubernetes?
8. What is a PVC in Kubernetes?

## Networking — 6 questions

1. Purpose of using CNI in K8s
2. CoreDNS in k8s
3. How will you know if a network policy is enabled or not in k8s
4. Pods in different namespaces can communicate. How would you block that communication? Where would you implement the NetworkPolicy?
5. Design a multi-tenant Kubernetes platform where teams must not affect each other’s resource usage, network traffic, or upgrade cycles.
6. How would you implement zero-trust networking inside Kubernetes without using a service mesh?

## RBAC / Security — 2 questions

1. how the end point authentication works in kubernetes
2. Do you handle IAM + RBAC in Kubernetes?

## HPA / Scaling — 17 questions

1. How to fix pod-level autoscaling not happening, what will be your approach .
2. suppose we have application configured with hpa where it was running fine but suddenly it is not running what will be your approach?
3. •    HPA triggers (what and all types of triggers you have used in HPA so far)
4. How will you create HPA
5. What is HPA and how do you implement it
6. What is HPA
7. HPA implementation in detail
8. How would HPA with stateful set work
9. When would you implement HPA and VPA. Give an example
10. What is the difference between scaling and autoscaling in Kubernetes?
11. Do you know what is HPA?
12. HPA & VPA.
13. Describe a real production incident where a misconfigured HPA caused cascading failure. How would you redesign autoscaling to avoid this?
14. How would you design container images for ultra-fast cold starts in serverless or autoscaled Kubernetes environments?
15. Do you use autoscaling (HPA)?
16. When to use HPA?
17. What are the parameters are used for HPA in K8s?

## Helm — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 27 questions

1. how did you troubleshoot the pod crashback loop
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
2. right? So how it is basically getting deployed in cluster? I mean the deployment is basically failing just on the pod is currently in the error state. It is getting terminated. So how are you going to troubleshoot those such kind of Kubernetes issues?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
3. Database connection from a pod is not working only for you. How will you troubleshoot?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
4. If your pod is in Pending state, then what are your troubleshoot steps?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
5. What are common Kubernetes errors you’ve faced (like CrashLoopBackOff, ImagePullError), and how did you resolve them?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
6. What is CrashLoopBackOff in Kubernetes?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
7. If any pod/node goes down how do you troubleshoot/monitor that( via cluster and other monitoring tools)
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
8. K8s architecture, services, if application pod fails how to troubleshoot
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
9. Kubernetes – Troubleshoot a worker node that goes down.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
10. Kubernetes – Troubleshoot a Pod stuck in Pending, CrashLoopBackOff, or ImagePullBackOff.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
11. You have a Kubernetes cluster with 30 nodes. 29 nodes are Ready, but 1 node is NotReady. You have already checked kubectl logs, kubectl describe, and other basic commands. How will you troubleshoot the node further?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
12. What are the common reasons for a Kubernetes node becoming NotReady, and how would you identify the root cause?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
13. Describe your approach to troubleshooting Kubernetes worker node issues beyond the basic kubectl commands.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
14. If you pod is not running, how do you troubleshoot it?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
15. Pod is in pending state. Reasons?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
16. In Kubernetes, if a pod is in a pending state, how do you troubleshoot?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
17. k8s node pending state how to debug
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
18. pod is pending state, due to disk issue, how to resolve
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
19. I have an Ingress object that is not routing the traffic to the Kubernetes cluster. What are the reasons and how do you troubleshoot that?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
20. U handled any debug/troubleshoot for kubernetes?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
21. 🧠 Kubernetes Reliability & Troubleshooting
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
22. Why does a pod show a “Pending” status in Kubernetes?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
23. If you have a Kubernetes cluster with pods running, but when you hit the URL you get HTTP errors (403, 404, 503), what would be your troubleshooting steps?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
24. In kubernetes a pod is going to crashloopbackoff, how do you troubleshoot.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
25. Kubernetes deployment done successfully but unable to access the application externally, how do you troubleshoot.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
26. After implementing HPA also some pods are in pending state. What maybe the reason
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
27. Possible reasons for pod to be stuck in Crashloopbackoff
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** pod status/events → describe/logs → deployment/ReplicaSet → scheduling/resources → node/kubelet/runtime → Service/endpoints → DNS/network policy/Ingress → probes/config/secrets
