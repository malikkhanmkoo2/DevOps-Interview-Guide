# 12. GITHUB ACTIONS

## Workflows — 9 questions

1. How do you prevent concurrent executions in GitHub Actions?
2. What is the difference between needs and concurrency in GitHub Actions?
3. How do you set up a manual trigger in GitHub Actions?
4. What is a matrix in GitHub Actions?
5. What is the needs keyword in GitHub Actions?
6. What is GitHub Actions Matrix strategy.
7. How caching works in Github Actions.
8. Explain your GitHub Actions pipeline.
9. ⁠diff between GitHub actions and Argo cd

## Jobs — 2 questions

1. In GitHub Actions, if one job depends on another job, which parameter do you use?
2. How do you run jobs in parallel in GitHub Actions?

## Steps — 2 questions

1. You are given a GitHub Actions workflow snippet. How would you identify incorrect steps and suggest improvements or missing steps for a robust CI/CD pipeline?
2. What steps are included in your GitHub Actions workflow file?

## Runners — 0 questions

_No matching repository questions in the uploaded material._

## Secrets — 0 questions

_No matching repository questions in the uploaded material._

## Artifacts — 2 questions

1. Do you have experience with GitHub Actions? Suppose I want to build and test a Java Maven application and create an artifact, what steps would you include?
2. Where do you keep the GitHub Actions workflow file, and how do you upload a JAR artifact?

## Environments — 0 questions

_No matching repository questions in the uploaded material._

## Reusable Workflows — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 0 questions

_No matching repository questions in the uploaded material._
