# 13. HELM

## Charts — 19 questions

1. Question : Walk me through what is there in helm charts and how it is integrated.explain me that what is written on your helm charts?
2. Explain the folder structure of a basic Helm chart. What commands do you use to deploy with Helm?
3. What is email signing and Helm chart signing? Which tools do you use to sign Helm charts?
4. If Git is already the source of truth, why do we need Argo CD? Why not deploy directly using the CI/CD pipeline with Helm or kubectl?
5. What is the syntax or command you follow to deploy an application using Helm Charts?
6. have you worked on argo cd , helm
7. Did you worked on helm charts?
8. Helm commands, how would you deploy an application via helm. How do you integrate this entire process via CI/CD
9. How the helm charts work ?
10. Do you actually use helm for the deployments ?
11. Do you have exp with helm?
12. ⛵ Helm & Application Deployment
13. Q8. Have you worked with Helm and Helm Charts?
14. Why use Helm instead of plain YAML?
15. Show the folder structure of a Helm chart.
16. Q9. How do you securely inject sensitive data into Helm?
17. Q10. Can a public Helm chart be customized?
18. Q11. How do you add extra Kubernetes manifest files to a public Helm chart?
19. what files will be present in helm chart

## Templates — 0 questions

_No matching repository questions in the uploaded material._

## values.yaml — 0 questions

_No matching repository questions in the uploaded material._

## Releases — 0 questions

_No matching repository questions in the uploaded material._

## Dependencies — 0 questions

_No matching repository questions in the uploaded material._

## Upgrades — 0 questions

_No matching repository questions in the uploaded material._

## Rollbacks — 2 questions

1. If a Helm release is partially deployed and some resources are updated while others have failed, how do you perform a rollback?
2. Helm – Upgrade failed. How do you rollback and troubleshoot?

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 1 questions

1. Walk me through the troubleshooting steps for a failed Helm deployment.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** rendered manifests → values → release history → hooks → Kubernetes events → resource readiness → chart dependency → rollback
