# 18. SRE / PRODUCTION

## Incident Management — 2 questions

1. Question : You mentioned about like the are you have architected a blameless postmortem framework, right? So for continuous learning, so how I mean what have you done to improve occurrence of critical incidents that you have mentioned in your resume.
   - **Answer approach:** Communicate impact and scope, stabilize first, assign investigation, maintain a timeline, document decisions, then complete RCA and corrective actions.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. which are the production incidents you had attended , pls explain
   - **Answer approach:** Communicate impact and scope, stabilize first, assign investigation, maintain a timeline, document decisions, then complete RCA and corrective actions.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## SLI / SLO / SLA — 0 questions

_No matching repository questions in the uploaded material._

## Reliability — 3 questions

1. Describe a situation where you had to improve the reliability of a critical system.
2. Position - Cloud Site Reliability Engineer
3. Position - Cloud Site Reliability Engineer

## Availability — 5 questions

1. What is availability zone and explain the layout on ground level.(in depth)
2. What is Region and Availability zone?
3. [ ] How do you design and manage a containerized environment to ensure scalability and high availability?
4. How does high availability work in MongoDB (primary and secondary nodes)?
5. how you ensure the best possible security for high availability architectures for 3 tier applications.

## Disaster Recovery — 3 questions

1. Have you worked on Disaster Recovery? Explain your DR strategy, including RTO, RPO, failover, and traffic redirection.
   - **Answer approach:** Discuss RPO/RTO, backup strategy, replication, failover, dependency recovery order, testing, and how you verify the recovered service.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. How would you structure disaster recovery for your applciation?
   - **Answer approach:** Discuss RPO/RTO, backup strategy, replication, failover, dependency recovery order, testing, and how you verify the recovered service.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
3. In a disaster recovery scenario, what will you do if users are not able to access the application?
   - **Answer approach:** Discuss RPO/RTO, backup strategy, replication, failover, dependency recovery order, testing, and how you verify the recovered service.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Capacity Planning — 1 questions

1. Question : What is your knowledge of production system sizing, provisioning, setup, maintenance, and closure?
   - **Answer approach:** Use current utilization, growth rate, peak traffic, headroom, scaling limits, cost and failure scenarios; validate with load testing.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Root Cause Analysis — 1 questions

1. Root cause analysis, troubleshooting approach, fix, and preventive measures.
   - **Answer approach:** Separate symptom from root cause; prove the causal chain with evidence, identify contributing factors, and define prevention plus detection improvements.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Production Incidents — 7 questions

1. explain the production issue which you have faced
2. What CVEs have you seen in production and how did you resolve them?
3. What branching strategy do you follow, and how do you handle merges to avoid breaking the release branch? If a bug appears in production, what’s your approach to resolving it?
4. New image has been deployed in production but it fails immediately what steps would you take ?
5. Tell me about a time you handled a failed deployment in production. How did you manage the team and stakeholders?,
6. Why does a container sometimes exit immediately even though the application works perfectly in local testing? Give 3 real production causes.
7. If a production instance is failing, what can be the possible causes?

## System Design — 893 questions

1. how to reduce the downtime with deployments
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. what agents you have deployed
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
3. suppose there are 100 applications how do you log analysis
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
4. difference between sre and devops
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
5. did you do any migrations from onpremises to cloud if so what challenges you have faced
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
6. provide the agent which you worked for customer or your company
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
7. tell me the cloud architecture which you have worked
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
8. If the frontend, backend, and database are all deployed in private subnets, how can an end user access the application?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
9. a) the master node goes down?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
10. b) a worker/slave node goes down?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
11. You have two tables:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
12. Customers(customer_id, customer_name)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
13. Orders(order_id, customer_id, order_date, amount)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
14. Example:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
15. ("job_id": 101, "status":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
16. "SUCCESS", "timestamp":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
17. "2025-06-10T10:00:00"), ("job_id": 102, "status":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
18. "FAILED", "timestamp":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
19. "2025-06-10T10:05:00"), ("job_jd": 103, "status":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
20. "FAILED", "timestamp":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
21. *2025-06-10T10:10:00"),
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
22. "job_jd": 104, "status":
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
23. "SUCCESS", "imestamp";
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
24. "2026-06-10T10:16:00")]
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
25. Note -: Guy,s in Every question, they asked to explain in briefly and the code and how it using and what will be outputs.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
26. 5/2 ?? and 5//2 ??
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
27. a = [0] b = {0}, what will be the result of a[0] and b[0]
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
28. Diff b/w Public and Private hosted zones
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
29. How will you create Kustomize file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
30. Diff b/w CMD & ENTRYPOINT
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
31. Interviewer introduced himself and explained the role, team setup, and expectations and asked me to itroduce
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
32. Infrastructure changes I have worked on. Deep discussion on architecture changes, optimizations, and real challenges faced.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
33. Branching strategy discussion in depth.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
34. Why this strategy was chosen
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
35. How it supports multiple environments, releases, and hotfixes.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
36. Alphadyne assessment ->>
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
37. multiple choice -
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
38. tool should a company use to automatedeploy configuration managing vm and container
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
39. Create multiple subnets for different layers (bastion, application, database)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
40. Provision Virtual Machines (VMs) using those NICs, with username and password authentication
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
41. Create Public IPs where required
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
42. Question : Can you describe your exposure to different environments like Dev, QA, and Prod?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
43. Question : What is your understanding of software architecture components (Load balancers, web servers, application servers, databases, and integrations)?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
44. Question : Describe your experience with infrastructure administration tasks like licensing, billing, cost reduction, and security.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
45. what is defined on your value dot yaml file?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
46. What is your approach of doing a troubleshooting?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
47. Question : can you tell me are you familiar with setting up dashboards and alerts yourself like creating dashboards and alerts?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
48. Question : So can you walk me through what all dashboards that you have created, what type of alerts that you have created?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
49. Question : can you explain me what is error budget?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
50. Question : What is what is an ideal burn rate?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
51. You also mentioned about basically to reduce the MTTR so can you explain me what automation that you have done?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
52. How to ensure all five application teams don't use more than a particular amount of space?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
53. what type of autmation you have done in k8
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
54. Tell what type of aumatation you have done that saved time in your project .
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
55. securityContext:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
56. runAsNonRoot: true
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
57. runAsUser: 0
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
58. Three tier architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
59. How will you build the image during CI and how will you manage it ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
60. How to configure Cluster auto-scaling, how to do that
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
61. How will you store all the configurations related to your monolithic app in Cloud,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
62. What are the security protocols will be taken into consideration while designing three tier architecture.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
63. DB migration, how will you sync the data,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
64. What service to use sticky session as an alternative option → redis,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
65. During a sticky session problem what will be the cause for LB.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
66. Do you create clusters in multi regions, is it possible? If yes, then how will you manage them,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
67. How will you take a back of your entire cluster regulary ?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
68. Diff between directory & mount,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
69. Explain me about three tier architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
70. What’s the purpose of CNI
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
71. When you type google.com, what will happen at backend in browser
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
72. When you type TOP command, what are the components will be displayed
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
73. CloudFront
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
74. I've a client and remote machine, how do certs communicate b/w them ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
75. How does SSL certs works
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
76. Comapny - Aspire
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
77. Position -
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
78. what is the difference between replica sets and daemon sets?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
79. what is the difference between pv and pvc in kuberenetes?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
80. in which cases 503 status code errors in devops?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
81. I have 5 jenkin jobs and how would you give view only acccess to other users.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
82. •    Stateful Vs Stateless
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
83. •    How do you manage data of stateless application?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
84. If everyone wants to use variables, what approach would you use?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
85. Troubleshooting
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
86. Security
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
87. What are CVEs?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
88. Name 5 tools to identify/fix CVEs.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
89. what is pid
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
90. did you use any automation in your daily work
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
91. if there is slowness issue in decouple (SQS), how would you handle it
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
92. what are the best practices can be used to keep the systems highly available
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
93. What is connection drain
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
94. Backend.tf file is showing in repo but it is not showing in storage account, what may be the issue
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
95. How to login VM if VM has private IP
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
96. You have deployed a web app and it was working fine but application went down, and all networking are fine and related ports are open, how to troubleshoot
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
97. Types of load balancers
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
98. App is down and throwing 503 err code, what steps should be taken
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
99. Also for question 4 is the answer the below?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
100. Check the status of nginx/apache service that was used to host the web app
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
101. Clearing cache/cookies from browser for stale enteries
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
102. Check SSL certificate if it has gone corrupt and is working fine
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
103. How do you manage terrform state file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
104. How would you design an architecture for a 2 tier application
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
105. Difference between cluster role and cluster role binding
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
106. What will happen when a IaC managed resource is modified manually, how would you avoid it
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
107. In a multi-account environment, if the resources are residing in one account and the users are in different accounts, how will you configure so that the user can access the resources?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
108. Asking different provisioners,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
109. How will I remove state file from locking?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
110. PVC.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
111. 1st Round
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
112. What key things should you verify post-upgrade?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
113. 2nd Round-:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
114. For deployment if you get timeout issue,  what kind of api gateway you used?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
115. And how did you managed security for application level?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
116. How to secure public api for on prem setup?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
117. Don't give me the formula. Just explain it in from business prospective?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
118. What is the difference between Interface Endpoint and Gateway Endpoint?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
119. How does Transit Gateway work and how did you configure it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
120. Once the backup is created, where will you store the log files?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
121. 𝗥𝗼𝘂𝗻𝗱 𝟭: 𝗧𝗲𝗰𝗵𝗻𝗶𝗰𝗮𝗹 𝗦𝗰𝗿𝗲𝗲𝗻𝗶𝗻𝗴
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
122. 𝗥𝗼𝘂𝗻𝗱 𝟮: 𝗜𝗻-𝗱𝗲𝗽𝘁𝗵 𝗧𝗲𝗰𝗵𝗻𝗶𝗰𝗮𝗹 𝗦𝗰𝗿𝗲𝗲𝗻𝗶𝗻𝗴
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
123. How do you establish a connection with databases in your deployments or infrastructure setup?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
124. What measures you will take to reduce the infra cost by 20%
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
125. Did you write any automation script that will use for cost optimization.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
126. difference between cmd and entrypoint
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
127. writ a script to search a pattern as 'error' and warning in test.log file. store the pattern with error in one file and  'warning' in another file. pass test.log in the argument
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
128. Is it possible to take AMI details from Snapshots
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
129. Diff type of instance profiles
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
130. AMI vs Snapshots
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
131. Development team changed the AMI configuration to ASG launch template, how will you make sure that the new version is deployed properly.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
132. How to find out if the provided IP is public or Private
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
133. Post connecting diff VPCs through TGW, I want to black the traffic of A to B and B to C, how to perform it
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
134. Enabling tight security to my LB
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
135. Is it possible to add multiple LBs to my sub web pages
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
136. I've huge traffic coming between 5 PM to 8 PM daily, how to configure this in ASG
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
137. Customizing WAF
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
138. Cloud Front configuration
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
139. Diff type of instances
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
140. API Gateway configuration
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
141. Diff between Private and Public IPs
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
142. Diff between Spot VS reserved instances
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
143. You are onboarding a new customer with 5 million+ users. How would you design the complete application architecture as a Solution Architect?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
144. You need to expose an application internally without using a LoadBalancer or NodePort service. How would you do it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
145. Have you worked on Databricks pipelines? Explain your experience with Databricks.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
146. What do you know about Apache Hadoop and its ecosystem?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
147. Introduction
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
148. Explain current project
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
149. Service mesh
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
150. Explain your current project.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
151. Have you deployed both applications and infrastructure? What kind of tech stack have you mainly worked on?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
152. For Java applications, what tool do you use to build them?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
153. What source code management tool have you used?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
154. What is the difference between Declarative and Scripted pipelines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
155. Have you used any artifact repositories like Nexus or Artifactory, and where do you store dependencies?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
156. What happens internally when you run a Maven build — how does it fetch dependencies from the repository?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
157. Have you used any security tool integrations in your pipelines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
158. What is Hash-based deployment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
159. What is a Service Mesh and how does it work?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
160. with respective storageaccount
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
161. Explain components in 3-tier architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
162. How is the image pulled from private repository
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
163. What are your roles and responsibilities in your current project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
164. Can you explain your end-to-end project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
165. What is a 3-tier architecture?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
166. How would you secure the web app running in cloud from oswsap10 attacks,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
167. Best practices to be followed for cloud security.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
168. There is db I made same entry(Name, Location) through PUT method twice what will happen.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
169. Why is PUT request called idempotency in nature. If I made another entry and name is same but location is differnet then what will db store.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
170. What happens if I type www.google.com in the background.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
171. What is SSL/TLS Handshake.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
172. What is K8. Explain the architecture.,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
173. How to find out second largest integer in an array
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
174. TLS handshakes
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
175. Different type of provisioners in TF
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
176. Diff b/w Local and remote provisioners in TF runners
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
177. Diff b/w user-data vs remote provisioner
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
178. Interview Questions for Flentas (3.5 Years
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
179. run?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
180. the LB only — how will you do it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
181. How and from where to clone repo, is there any local repo you are using and then transferring from local to remote or how? (Honestly I didn’t get this Q, if anyone has real time exposure pls explain)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
182. What is PAT
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
183. How to configure sonarqube
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
184. What is the output of sonarqube, how to fix if any smell code/vurnabilities  found
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
185. what is diff between pv and pvc
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
186. Expalin kuberenets arthciecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
187. what is diff between deployment and statefullset
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
188. what is calico
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
189. what is etcd
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
190. how to take bakcup of kubenretes cluster
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
191. what is rolling update
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
192. what is deployment statgergy you are using
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
193. what is statefullset
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
194. Supoose you have taked etcd backup and old vm corrupted ,can we create new vm with backup etcd ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
195. Landing zone, guard trail, scp, control tar. —— interviewer ask for this vocabulary ❌ (general)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
196. Have you used permission boundaries ❌ (-)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
197. Have you worked on transit gateway ❌ (-)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
198. How do you display the last 10 lines of a large log file without opening it fully?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
199. What top-level security risks from OWASP do you usually check for?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
200. If you have an on-prem application, how would you migrate and deploy it in a cloud-native environment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
201. Encrypting the EBS volume
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
202. How do you securely manage TF state files, secrets, and environment isolation?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
203. If I've three Master Node, one is down, what will happen
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
204. Global LB in Kube
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
205. AB Testing
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
206. How will you check the vulnerability of your code
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
207. If there are two clusters running in diff regions, if there is an issue with one cluster, how to shift the traffic to another cluster.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
208. In Log file, how to fetch 200 status code
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
209. Q2: we are going to launch a website with many different products
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
210. running many services and is expected to get high load during black friday
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
211. how would u set up and make it highly available?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
212. Q3: users are facing slownesss issue, what will u do to resolve?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
213. Q6: now the application is hosted and running, the billing is too much, the client asks you to
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
214. reduce the billing by doing the needful, what would you do to reduce billing?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
215. Q9: In lambda function, how would you handle failures and how would you set up retries?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
216. Q10: Lets say we have already hosted and app, now some changes has been made
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
217. How would you redeploy this application with zero down time?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
218. Write a script to delete files older than 10 days.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
219. What is hard and soft link
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
220. What tools do you use for configuration management?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
221. How to run a container on ecs cluster.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
222. How you are mangaing the kubenretes DR
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
223. Introduction
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
224. Current Company project related questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
225. What task and activities do you do on daily basis
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
226. What is Kibana
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
227. How is Kibana set up
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
228. What is log rotate job and how does it work
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
229. Basic Kuberntes commands
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
230. How is traffic routed inside kuberntes clusters
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
231. How do you receive alerts in your project and how is it setup
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
232. What are indices, index in Kibana
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
233. Cronjobs
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
234. Paas Questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
235. What all Kuberntes issues you have worked on
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
236. What is your day to day activities
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
237. You branching strategy
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
238. What is your team size
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
239. Tell me one task or tool that your have done from scratch
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
240. What are the tools you use in your project
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
241. Give me an crisp overview of your client like are they banking project.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
242. How the data is fetched to promotheus
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
243. What are the alerts you setup on graffana
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
244. What is desired state and in-desired state?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
245. There are 2 VPCs A & B. Give me options so that A communicate to B and vice versa. Also, option where only A has to communicate to B.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
246. Explain the project you are currently working on.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
247. What types of Spring Boot starters have you used in the project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
248. How have you implemented transaction management?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
249. How are you managing code coverage in your project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
250. How do you perform load testing for your application?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
251. How have you implemented security in your project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
252. Explain Okta integration for identity and access management.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
253. How do you secure internal communication between microservices?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
254. How do you implement a retry mechanism for a failed API call?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
255. How would you handle scenarios where the payment succeeds but the order or shipping service fails?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
256. // List of duplicate color and count it , create a map using stream.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
257. // Remove a duplicate colors from the list and make it unique list.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
258. You have two candle how you r going to calculate 45 mins, you are not allow to cut or measure .
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
259. How do you provision container-based services for microservices deployment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
260. What database services did you provision along with your application?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
261. Where do you define auto-scaling parameters?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
262. What do you know about Serverless architecture?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
263. How do you monitor the health of your microservices?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
264. How do you enable Spring Boot Actuator?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
265. Are actuator endpoints accessed without authentication?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
266. Have you worked with Kafka or any other messaging service?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
267. Have you used any serialization or deserialization frameworks?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
268. Where do you register the Avro schema you're creating?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
269. Have you implemented any concurrency APIs in Java?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
270. How do you combine the responses of three separate APIs?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
271. What is active-active ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
272. How active- passive is differ from active-active ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
273. //Find all pairs in an array that sum up to a specific number
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
274. Can you share your previous experience?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
275. Have you recently worked on any challenging tasks in your project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
276. How do you deal with high-pressure situations or multiple critical deadlines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
277. If your lead or team member is not technically strong or doesn’t behave well, how do you handle the situation and continue working as a team member?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
278. What do you do in your free time or on weekends?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
279. If your statefile is deleted..how can you recover without recreating resources.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
280. Suppose you found a malware in client's machine and now you want to get rid of it and set up a environment which will be free from malware attack. How to achieve it.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
281. What is spot, reserve instance, on-demand instances.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
282. Whats are the strategy to deploy a application.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
283. What are cloud watch, cloud trail, cloud matrix
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
284. If some resource is deleted how can you identify which resource is deleted.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
285. Difference between roles and policies
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
286. what's the strategy you are using for zero downtime..how to acheve it…explain it
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
287. Difference between cmd and entrypoint
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
288. diff between statefull set and stateless app
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
289. can we delete pause conatiner
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
290. Suppose we removed 2nd instance name from the list and applied script again then what will happen to the already 3 instances created before.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
291. Difference between code quality and code coverage.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
292. What is default qualitygate in sonar
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
293. How to run a yaml manifest without a yaml manifest file created.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
294. How do your day starts and what activities you perform
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
295. Create manifest for 2 nginx replicas
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
296. What is cherry-pick
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
297. What is dockere compose
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
298. explain k8 archtiecure
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
299. Diff between virulastion and conteraziation
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
300. what is stragey to do conterzation of an application
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
301. how your approach to do migration an app  from montholic to conterization
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
302. What is loadbalancer in k8
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
303. Can conatiner can restart itself how explain?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
304. access control in k8
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
305. what is kubeproxy
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
306. how to get static ip of k8 how to manage
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
307. Have you used HashiCorp Vault for secret management?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
308. How do you store and retrieve secrets from HashiCorp Vault?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
309. What are the different authentication methods or injectors supported by HashiCorp Vault?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
310. Can you briefly introduce yourself and explain your background relevant to DevOps/MLOps?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
311. If batch jobs are running for ML workloads, how do you handle deployments without impacting ongoing processing?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
312. Ulimts
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
313. You got an error like "Too many files are open" in your script, what will be the fix
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
314. A and CNAME
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
315. Date is behind the current date in VM, how to fix that
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
316. Cross-Origin Resource Sharing
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
317. Purpose of sed command
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
318. Is it possible to add multiple alias to domain
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
319. If I have two different domains, how to enable a communication between them
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
320. Creating certs for multiple sub-domains
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
321. Hardlink and Softlink
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
322. Using sed command, how to remove first and last line of the file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
323. How to fetch error from log files
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
324. Two containers are there. One with front end application and second container has db.Fisrt I want to start db then front end. What should you do?( 2tier application)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
325. How do you call pod1 to pod2 without service.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
326. Best practices to structure repos and pipelines in a large DevOps project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
327. If someone force-pushed and lost the main branch, how do you recover it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
328. How to push the recovered branch back to remote?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
329. about Maven release
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
330. about maven lifecycle
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
331. about dependency management tag
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
332. what will happen with maven install
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
333. what are the types of branching stratergy u r using
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
334. in which directory or in which place ur pom.xml there
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
335. Diff between Role and Role binding
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
336. If I want to deploy my app in worker node2, what should I do ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
337. Diff between Nodeselector, node affinity VS Taint, toleration
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
338. What command will you give for view access for the cluster → READ in rolebinding.yaml file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
339. NFS
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
340. Comapny - Nice
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
341. Comapny - Nice
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
342. [ ] Can you brief through your profile?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
343. [ ] Is it client-based work or are you just in the middle of deployment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
344. [ ] What is your approach to integrating automated testing in pipelines to ensure high code quality?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
345. [ ] How do you integrate tools like SonarQube into your pipelines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
346. [ ] Any other advantages of using YAML pipelines that you have experienced personally?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
347. [ ] What branching strategy do you follow for source code management in a large team with a complex application?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
348. what is scrapper?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
349. can we deploy services on master node?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
350. Did you upgraded any services?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
351. what is deployment stratergy that you are following?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
352. what is differnece between COPY and ADD commands ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
353. Any experience on phython/shell scripting? can you explain one file?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
354. Expalin about fargate?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
355. Image: nginx:1.25
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
356. Replicas: 3
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
357. Labels: app=web
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
358. What is something you have implemented end to end in your project
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
359. Why would you deploy rabbitmq as stateful set why not deployment
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
360. Deploying a 3 tier architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
361. Your approach (Set of tools you would pick up)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
362. What kind of database you would use
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
363. How would you manage these microservices
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
364. How would you expose the application
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
365. Is load balancer required in this setup why?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
366. Is nginx required in this setup
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
367. How would you manage SSL and TLS
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
368. How would you update the image and deploy them
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
369. Want to know how many users are affected ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
370. Which metric will tell me regarding the application is up or down?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
371. Explain me all the components present under deployment.yaml file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
372. If TF statefile is corrupted, how to fix it ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
373. TF Lifecycle (create / after destroy)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
374. Explain me the three tier architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
375. What are the types of services and explain each
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
376. What is custom resource definition
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
377. What is the role of container runtime and which runtime do you use and why?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
378. What is traffic mirroring in istio
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
379. I have an apache tomcat application running in k8 cluster, what are the manifests files you will be having inside in it
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
380. Senior Cloud Administrator
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
381. ECR
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
382. Node selector, taints tolerations
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
383. What is the controller used to manage the self managed worker nodes
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
384. What is karpenter. On which metric does it scale up and down?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
385. How many clusters are you managing currently, No of addons you have deployed
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
386. Why would you need an application to be deployed as stateful set
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
387. What factor motivates you for this role?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
388. Explain how you did your cloud migration
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
389. L1 Questions:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
390. In Airflow, if a job fails, how do you debug it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
391. 🔥 L2 Questions:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
392. Explain Declarative vs. Scripting pipelines.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
393. How do you enable passwordless authentication between two servers?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
394. Devops interview questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
395. Architecture of K8
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
396. What happens if etcd stops working
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
397. What are the types of services
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
398. Why is load balancer used
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
399. service vs deployment
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
400. Self intro
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
401. Difference between secret manager and parameter store
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
402. Why to use Self hosted runner instead of default runner
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
403. How DRS works.. explain the architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
404. How failover and failback happens in DRS
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
405. Difference between tf validate and format
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
406. What are provisioners and how to use
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
407. Total  - 4 Technical Round, 2F2F and 2 Virtual Round.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
408. What is MongoDB, and how does it work?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
409. What is artifact management, and which tool do you use in your organization?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
410. How do SSL and TLS certificates work?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
411. Explain the Maven lifecycle.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
412. In a log file, there is a keyword ERR. Give me the count of errors in the file.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
413. a. Code is pushed to a specific branch?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
414. b. Ignore if it is pushed to some other branch?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
415. c. Trigger if a PR is raised?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
416. What is SonarQube, and why is it used?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
417. Briefly explain the architecture of your current project.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
418. Round 1: Technical Interview Questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
419. See Thread ›
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
420. There are no messages in this thread yet.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
421. Round 2: Techno-Managerial Interview Questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
422. How do you handle secrets in your project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
423. Which is the optimized method to run SonarQube: for every PR raised or every push?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
424. What are webhooks, and have you used them anywhere?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
425. Suppose during upgrade storage plugin had issue, unable to upgrade, what u will do ? (couldn't answer properly)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
426. what is pullsecret in Openshift, there were 1 more but forgot
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
427. how do u handle sev-1 issue
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
428. Imagepullbackoff, why and when this usually occurs ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
429. How do you debug inside the container ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
430. Explain the rolling update ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
431. If there a deployment failure what the next steps you perform ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
432. How do you approach the debug on the deployment failure.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
433. If any sensitive data needs to passed in the deployment how do you pass it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
434. what are secrets ? for what type of applications we may need them?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
435. your deployment is successful, but when u access the application it says 404 ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
436. What are the api errors you have faced ? what is 504 ? 501 ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
437. Explain what an api is ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
438. some questions went around API and diff between authorization and authentication.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
439. they it shifted towards the shell scripting - I dont really have enough knowledge on shell. My answers were blunt, and they moved on from it.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
440. Cost optimization strategies that you followed in your project
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
441. Trunk based Branching strategy
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
442. CMD vs entry point
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
443. Pvc is in pending state how do you debug
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
444. If app is responding slow how do you debug and what could be the issue
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
445. Any migration experience
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
446. How did you manage secrets in your project?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
447. How does service mesh work and any experience?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
448. I have 5 Jenkin jobs and how would you give view only access to other users.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
449. How sensitive data is managed in pipelines
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
450. Which App gateway setting is used to upload SSL certification and why
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
451. he has asked to list the running instances from 5 accounts , I have written it  with sts
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
452. how is the connectiivy from on prem to cloud
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
453. file system is 50% however its not able to write and df -ih is shoiwng full
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
454. Can u pls write a lambda file?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
455. About K8's Architecture and tell me the workflow?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
456. about RBAC
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
457. There were More Scenario Questions Related to "Load Balancers",
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
458. Diff b/w SGs and NACLs.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
459. where do you use firewalls, SGs and NACLs
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
460. What are the best password security practices used by your organisation?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
461. Explain about the transit gateway and why do we use this?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
462. Suppose I have given one command in null resource, it should run every time. What is the behavior?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
463. What is the difference between an EBS-backed instance and a non-EBS-backed instance?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
464. I have 3 nodes (small, medium, and large), and I want only data load to go to the large node. How can I do that?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
465. I am getting the following error, how can I debug that and what does the error mean?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
466. If I don't specify TargetPort in the service object, what is it going to do?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
467. I have created a service object that is not mapped to a deployment. What could be the reason and how do you debug it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
468. If I select the restart policy as Never, what is it going to do?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
469. What is an init container and why do we need to use it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
470. Write a script that renames all .txt files in a directory by appending the current date to the filename.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
471. Introduction
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
472. Which scriting language u r aware? and how much confident on that?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
473. If U want to design a infra for high scalablity, how did u do that?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
474. About ConfigMaps,PV,PVCs
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
475. write a Deployment file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
476. What is the toughest situation u r faced while implementing anything and what did u learnt from that?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
477. About Fargate
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
478. What is lambda functions? did u used any Lambda functions? what did u acheived from that?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
479. From one of the linkedin post >
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
480. interview experience happened yesterday (08-02-2025).
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
481. How you managed statefile
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
482. So how are you managing the conflict? State file conflicts
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
483. what is the dynamic auto scaling?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
484. How can achieve the requirement?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
485. /var partition is 90% full. What’s your immediate action?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
486. Add 50GB to /opt using LVM without any downtime. What are the steps?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
487. How do you ensure smooth collaboration between development and operations teams in a high-pressure situation?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
488. Describe a scenario where you had to introduce a new DevOps tool or practice. How did you get team buy-in?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
489. Tell me about a conflict you faced within your DevOps or cross-functional team. How did you resolve it?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
490. Explain a situation where you were responsible for reducing deployment time. What approach did you take?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
491. How do you approach communicating technical issues to non-technical stakeholders or management?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
492. Can you share an experience where your automation strategy failed or caused problems? What was your corrective action?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
493. You are asked to reduce infrastructure cost without compromising performance. How do you approach this challenge?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
494. How do you ensure accountability and ownership in a DevOps team, especially during failures?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
495. Describe a time when you had to work under tight deadlines. How did you manage team workload and expectations?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
496. How do you mentor or support junior DevOps engineers in your team while ensuring timely project delivery?,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
497. Tell me about a successful DevOps transformation project you were part of. What was your role, and how did you drive change?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
498. SRE role -:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
499. How do you grant access to user?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
500. How does a three tier architecture looks like? Compare it with two tier
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
501. How to achieve zero downtime application upgrade?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
502. Have you contributed any automation initiatives in your current company as a DevOps engineer?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
503. When you deploy from CI, you build a package and then need a platform to deploy the application. How do you build that platform, and if it requires human intervention, how do you eliminate that dependency?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
504. Each row should contain consecutive numbers, but printed in reverse order, and the number of elements in each row should increase by one.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
505. Explain your current project and your activities in it.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
506. what is Stale branch.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
507. ACM
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
508. CloudTrail
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
509. CloudFront
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
510. CloudFormation.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
511. Where does NATGateway reside.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
512. Explain your last project
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
513. What are microservices?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
514. Have u handled lambda? Explain your project
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
515. How would you decide on the type of environment required for deployment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
516. What is Athena?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
517. You said you configured SonarQube. What does SonarQube do?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
518. Which version of SonarQube have you used — Community, Developer, Enterprise, or SonarCloud?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
519. In your project, what was the application language you scanned with SonarQube?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
520. How do you set up quality gates in SonarQube?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
521. What are access modes in PVC?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
522. You have mongoDB db dump, from that you need to clear some space out of it. How will you do that?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
523. Different types of services?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
524. what is nodeport what are the cases we can use it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
525. what are loadbalancer used?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
526. How can you restrict public access to load balancers either standalone or gke?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
527. How can you can you migrate one node pool vms to another node pool in gcp?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
528. If vm deployed in private subent how can you do patch updates like apt update?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
529. What is IAP in gcp?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
530. How can you reduce gcp storage buckets costs?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
531. What things have you worked and your experience in brief?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
532. You have a multi-cloud environment. How do you manage pipelines for all those cloud environments?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
533. How would you perform database migration for your database application?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
534. You have a crashbackloop error. How would you fix this error?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
535. Difference between deployment and stateful sets?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
536. RelevantZ interview questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
537. Which deployment is better cost wise.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
538. How the auto scaling works, how things work in the back-end, from worker nodes to master nodes. Communication track behind that.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
539. How will you maintain your base image, vulnerability free?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
540. How will you perform the patches regularly
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
541. Comapny - Sapient
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
542. Position -
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
543. In your project, what was your domain name? How are you establishing connection between domain name and service?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
544. How many subnets are you having?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
545. Where Load Balancer will be there?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
546. EBS: Suppose you are maintaining data in EBS (sensitive data) — how are you securing those data?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
547. Iteration limit – what is it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
548. What is the data block?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
549. How are you calling your modules?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
550. Have you worked on null resources?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
551. Reverse the string using For loop
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
552. Check if the palindrome using For loop
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
553. "Hello World Hello" --> Check how many times hello got repeated
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
554. Diff between replica set vs replication controller
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
555. How do you handle deployment failures
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
556. What happens if master node fails suddenly
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
557. asked me to write request and limit usage YAML file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
558. Write a deployment file for the below requirement
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
559. *Create a Deployment named 'space-alien-welcome-message-generator' of image 'httpd:alpine' with one replica.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
560. *The initialDelaySeconds should be 10 and periodSeconds should be 5
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
561. If Liveness probe is healthy and readiness probe is failing, what will happen
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
562. How will you find out the data loss while switching back to DBs
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
563. How to enable RBAC to Service accounts
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
564. Write a script to capture the failures
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
565. Input :
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
566. 2025-05-23 10:00:01 ERROR: Connection failed to database
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
567. 2025-05-23 10:01:02 INFO: Retrying connection
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
568. 2025-05-23 10:01:30 ERROR: Connection failed to database
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
569. 2025-05-23 10:02:10 ERROR: Connection failed to database
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
570. 2025-05-23 10:03:55 ERROR: Connection failed to database
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
571. 2025-05-23 10:06:00 INFO: Recovery attempt successful
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
572. 2025-05-23 10:07:20 ERROR: Timeout while reading from API
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
573. 2025-05-23 10:08:15 ERROR: Timeout while reading from API
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
574. 2025-05-23 10:09:10 ERROR: Timeout while reading
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
575. output :
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
576. [ALERT] 'Connection failed to database' occurred more than 3 times
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
577. [ALERT] 'Timeout while reading from API' occurred more than 3
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
578. If LB is created in us-south and that region is down what will happen ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
579. New web deployment was done today, how will you make sure that particular application is behaving and we need to find out the issues before user's figures out
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
580. Practical difficulties in having the infra in two different regions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
581. Failover mechanism in LB
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
582. Is it possible to have ASG and LB in different regions ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
583. Creating custom images
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
584. Create system design for three tier architecture with secuirty and avalability in place.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
585. #Given a string s, find the length of the longest substring without duplicate characters.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
586. #Example 1:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
587. #Input: s = "abcabcbb"
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
588. #Output: 3
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
589. #Explanation: The answer is "abc", with the length of 3.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
590. #Example 2:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
591. #Input: s = "bbbbb"
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
592. #Output: 1
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
593. #Explanation: The answer is "b", with the length of 1.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
594. #Example 3:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
595. #Input: s = "pwwkew"
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
596. #Output: 3
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
597. #Explanation: The answer is "wke", with the length of 3.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
598. #Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
599. Round 1 (F2F technical - whiteboard round):
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
600. Round 2(F2F technical round with cloud devops architect):
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
601. Round 3 (F2F managerial + technical round):
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
602. finger,comm, netstat, jq, yq, at, atq, shuf, lsblk, less, last, nc, mtr, iftop, lsof, blkid, mkfs, nice
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
603. eg:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
604. file.txt
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
605. C,23
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
606. A,41
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
607. A,67
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
608. Q,44
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
609. C,29
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
610. B,88
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
611. A,12
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
612. If input=A, then min = 12, max = 67 , sum = 120
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
613. If input=B, then min = 88, max = 88 , sum = 88
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
614. eg:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
615. app.log
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
616. Connection established from : 145.11.21.78
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
617. Connection established from : 189.22.99.19
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
618. Connection established from : 145.11.21.78
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
619. output should be: 145.11.21.78 , 189.22.99.19 , count=2
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
620. Can you tell me what is cold start in Lambda?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
621. Have you worked on API Gateway?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
622. Can you tell me the difference between REST APIs and WebSocket APIs in API Gateway?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
623. How do you protect an API Gateway?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
624. How do you protect the secrets in Secrets Manager?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
625. What is the use case of Auto Scaling?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
626. Will Auto Scaling automatically scale up? How do you set that up?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
627. How does Aurora handle automatic backups?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
628. Have you worked on AppConfig?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
629. Scripting / Programming Questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
630. Which scripting language have you used?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
631. Can you tell me the difference between single ampersand (&) and double ampersand (&&) in shell scripting?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
632. What are the vulnerability reports in your sonarqube.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
633. (Storage, networking, controllers, quorum, recovery)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
634. 🏗️ Infrastructure & Architecture
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
635. Q1. Explain the infrastructure and application setup of your last project. How is the application hosted?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
636. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
637. Where exactly is the frontend hosted?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
638. Where is the backend hosted?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
639. Where is the database stored?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
640. What part of the infra do you manage personally?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
641. What are the microservices doing?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
642. Why did you choose this architecture?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
643. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
644. Do you participate in cost-optimization?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
645. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
646. How do you manage worker nodes?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
647. How many replicas do you run?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
648. Do you use Cluster Autoscaler / Karpenter?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
649. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
650. How did you configure node groups?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
651. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
652. What risks come with upgrading?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
653. How do you handle node draining?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
654. Do deployments get recreated?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
655. What checks do you perform post-upgrade?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
656. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
657. How do you map users and roles?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
658. Do you provide RoleBinding or ClusterRoleBinding?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
659. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
660. What sections inside it? (mapUsers, mapRoles)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
661. What mistakes can break authentication?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
662. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
663. What is the templates folder?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
664. What is values.yaml used for?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
665. How do you manage multiple environments?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
666. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
667. Do you avoid committing secrets in values.yaml?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
668. What is Sealed Secrets?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
669. What is the purpose of --set and --set-file flags?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
670. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
671. Why is it not recommended to edit the chart directly?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
672. How do you update config safely?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
673. What happens during chart upgrades?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
674. How do you extend a chart with new templates?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
675. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
676. Where do you put extra YAML files?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
677. How do you reference new values?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
678. Can this break the original chart?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
679. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
680. Why EFS over EBS?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
681. What is the EFS CSI driver?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
682. What are the access modes?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
683. How do you mount PVC in deployment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
684. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
685. What access mode does EBS support?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
686. Why can't EBS work across multiple nodes?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
687. When is EFS mandatory?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
688. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
689. What is voluntary disruption?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
690. What is involuntary disruption?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
691. When do we use minAvailable vs maxUnavailable?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
692. Q15. What is your approach to debug a CrashLoopBackOff?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
693. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
694. How do you check events?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
695. How do you inspect liveness/readiness probes?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
696. How do you check resource limits?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
697. How do you inspect environment variables and config maps?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
698. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
699. Load balancer throttling issues?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
700. Endpoint misconfigurations?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
701. Are readiness probes failing?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
702. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
703. Why is static scaling bad?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
704. When to use Cluster Autoscaler?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
705. Q18. Why choose EFS over EBS?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
706. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
707. Which one supports multi-node?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
708. Which one is cheaper?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
709. Which one is faster?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
710. Q19. Can EBS be attached to multiple nodes? Why not?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
711. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
712. Explain RWO vs RWX
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
713. Who enforces the mount restriction?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
714. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
715. How do you run iOS build automation?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
716. How do you handle secrets in pipelines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
717. Q21. How do you handle multi-environment pipelines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
718. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
719. Dev → QA → Prod
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
720. Promotion strategy (manual approvals?)
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
721. Q22. How do you implement rolling deployments?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
722. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
723. What is maxSurge, maxUnavailable?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
724. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
725. Show module structure.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
726. Show provider file.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
727. How do you manage remote backend?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
728. How do you manage state locking?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
729. What is a data block?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
730. What is a module block?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
731. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
732. Are you confident in these?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
733. Have you worked on cost optimization?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
734. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
735. What is the logic behind a custom policy?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
736. What is "Explicit Deny"?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
737. How would you restrict everything except two services?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
738. Which policy pattern do you use (Allow + NotAction Deny)?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
739. 💰 Cost Optimization
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
740. Q3. What exact cost optimization steps have you implemented?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
741. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
742. What was the % saving?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
743. Have you used Reserved Instances or Savings Plans?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
744. Which scenario costs more?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
745. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
746. Does it go out to internet?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
747. Does it come back through IGW?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
748. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
749. How do you configure the agent?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
750. Do you need to update Launch Template?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
751. Q6. In a versioned bucket, how do you delete objects + all older versions after 10 days?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
752. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
753. What options appear in lifecycle rules?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
754. Do we explicitly delete previous versions?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
755. What is the difference between Current vs Previous versions?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
756. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
757. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
758. Can you kill heavy queries?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
759. Remove idle connections?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
760. Create a read replica?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
761. Which action applies instantly?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
762. Which action causes 0 downtime?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
763. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
764. Which one is stateless?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
765. Which one is stateful?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
766. Which takes precedence if conflict?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
767. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
768. Why not?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
769. Which one checks traffic first?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
770. How many IPs does /32 allow?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
771. Q11. Does IP 10.11.7.44 fall under 10.11.0.0/16?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
772. Q12. Does IP 10.11.44.76 fall under 10.1.0.0/16?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
773. Q13. What does /32 represent?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
774. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
775. How many IPs in /32?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
776. Which exact IP?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
777. Q14. Repo has 3 branches: dev, staging, prod. How do you ensure pushing to staging triggers only staging deployment?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
778. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
779. Use of branch conditions?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
780. Environment variables?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
781. Webhooks?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
782. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
783. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
784. How to get Sonar token?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
785. Where to store token?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
786. How to insert Sonar scanner stage?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
787. What is quality gate?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
788. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
789. Node resources?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
790. External API calls?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
791. When do you restart agent?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
792. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
793. Local state or remote backend?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
794. Why is storing secrets in plaintext dangerous?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
795. Q20. What does a module contain?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
796. Q21. What is in main.tf?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
797. Follow-ups:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
798. variables.tf?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
799. outputs.tf?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
800. providers.tf?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
801. How do you call a module from root module?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
802. Taint and Tolerations
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
803. If you want your developers to use only authorized images, what can we do ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
804. What is pom.xml in maven
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
805. What are the all the issues you had faced in your project, please explain
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
806. Will you register app service first or deploy it
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
807. Have you used any scripting language for automation purpose
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
808. What is self hosted agent and Microsoft host agent
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
809. Tell me about the ADD and COPY commands ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
810. What is backend ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
811. What is the difference between Find and sed ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
812. How to find the 10th word  in a file ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
813. How to moitor the system performance?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
814. What is Blue Ocean in  Jenkin ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
815. How to configure the Flask in Jenkin, tell me procedure ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
816. Tell me the difference betweeen Cloud watch and CloudFormation ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
817. How  will you create the Custom alerts, tell me the procedure.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
818. What is Ansibler galaxy ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
819. Tell me Kubernet architecture  ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
820. What is Monkey Patching?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
821. Have you worked on SRE ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
822. Tell me the difference betweeen DEVOPS and SRE ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
823. Client -Morgan Stanley,
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
824. What is jfrog artifactory
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
825. what is nagios , how to integerate jenknins in nagios
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
826. what is jinja2 template
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
827. what is jfrog xray
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
828. what is jfrog uses cases
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
829. what is branching stargery
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
830. what is differnet type repo in jfrog
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
831. Explain your current e-commerce project and its architecture.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
832. What is CrashLoopBackOff, and how do you troubleshoot it?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
833. When you run a module like yum or apt and get “command not found,” what’s the reason?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
834. Gemini company interview questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
835. What happens if we scale a Deployment with one PVC from 1 to 3 replicas?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
836. Failover happend in DB, so connection is switched from A to B, during this time interval, if user is writing some data, how to manage that ?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
837. Lamdba cold start
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
838. I've payment gateway app running in Lambda, sometimes there was an issue with connecting to external API, how to cross check and fix it while performing the payment
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
839. Write a script to check if the external API is reachable before starting the request.
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
840. How can AI assist developers in increasing their productivity?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
841. Etcd is sql or no sql database and reason
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
842. what is chart.yml file contains in K8
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
843. what you will declare in values.yml etc
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
844. what is taint and tolerations in K8
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
845. what is task definition in ecs
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
846. what is the difference between ecs and fargate
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
847. ==
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
848. Looking for both DevOps (70%) and development (30%).
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
849. What is the difference between vertical and horizontal scaling?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
850. What is your day to day activity
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
851. What to do if an application is down
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
852. Scenario based includes 3 sub-questions
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
853. a) If any service is down for more than 2 weeks and customer is asking for update, what will you tell to customer?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
854. c) what steps to take so that the issue will not happen in future
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
855. Contents written inside deployment.yaml or heml chart
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
856. When dealing with multi tenant applications, how do you enforce tenant isolation at the API layer?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
857. If clients reporting 504 Gateway Timeout errors. describe your approach to debugging the issue?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
858. how would you implement optimistic locking a RESTful update endpoint to avoid lost updates?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
859. if you were required to run pre-task checks, main tasks and post-task validation for patch automation, how would you structure your RedHat Automation & Virtulization scripts?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
860. How do you mitigate the risk of misscommunication when there are multi-lingual stakeholders involved in email threads?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
861. How would you parameterize a workflow so that downstream jobs know which environment to deploy to?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
862. How would you implement feature toggles in Deployment pipelines?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
863. If you have a monolith application and need to convert it to microservices, what prerequisites would you ask from the development and tech teams before starting the work?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
864. When you have many services in a service mesh, how do you decide the number of control planes and data planes needed?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
865. What security measures and policies should be put in place when using a service mesh?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
866. Since some features of service mesh are also available through other tools, is it worth adding the burden of installing Istio service mesh into the estate?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
867. How do you handle the service discovery phase when moving from a monolith to microservices?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
868. In your 4-year career, what is the biggest achievement you are most satisfied with?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
869. Do career achievements always need to be big and complex, or can they also be simple improvements?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
870. Is a service mesh always needed, or are alternative tools sometimes enough?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
871. MiscImp Qst -:
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
872. ⁠how do you manage state file
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
873. ⁠explain your roles and responsibilities
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
874. ⁠Types of alerts in dynatrace
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
875. ⁠did you install one agent in your applications
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
876. ⁠different types of modules and why it’s used
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
877. ⁠what is route table
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
878. Can you brief your self and your project and responsibilities
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
879. what is maven and explain about repositories
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
880. Layer caching, explain with an example
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
881. Design an architecture for the scenario: if I type www.application.com it should get resolved to the backend service
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
882. How would you provision karpenter. What all things are needed in configuration
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
883. How would karpenter know which node to provision. How would it get to know about resource constraints
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
884. How would the service account know which role to assume. What all things you would need to configure in the service account
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
885. questions on modules
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
886. What is service connection/connection string
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
887. What is DR
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
888. What is agent?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
889. Diff between replica set and deployment
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
890. Diff between stateless and stateful application
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
891. If control plane goes down what will happen to worker plane?
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
892. What is etcd and its use
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
893. How to create app registration
   - **Answer approach:** State assumptions, traffic/availability requirements, architecture, data flow, scaling, failure handling, security, observability, deployment and DR.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
