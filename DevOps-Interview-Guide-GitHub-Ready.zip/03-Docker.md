# 03. DOCKER

## Fundamentals — 32 questions

1. Diff b/w using VM vs Docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
2. Types of storage drivers in Docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
3. Does Docker have kernel in place
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
4. C name and namespace in docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
5. Docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
6. Purpose of Docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
7. What is the purpose of Docker?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
8. What is inside docker file
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
9. what is docker multisatge , why it is used and all
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
10. What is Docker and how do you use in your project, Any docker file you have written
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
11. What is docker file
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
12. what is docker compose depends_on
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
13. Docker:
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
14. How do you get logs from docker level.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
15. What is docker file what is inside it
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
16. Why K8 instead of docker swam
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
17. Explain a project in which u used Docker K8 and CICD
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
18. Write a simple docker file
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
19. How do you configure a pipeline with AWS or Docker?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
20. They they started to evaluate the knowledge on docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
21. basic questions like docker build docker file and so on.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
22. Write a Docker File
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
23. About multistage Docker file
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
24. what is difference between add and copy in docker file?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
25. How can you reduce the docker build size?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
26. How you worked on docker swarm before?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
27. How to create sub user while writing Docker file
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
28. Tell me the difference between Docker and Docker Compose ?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
29. what is the difference between copy and run command in docker
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
30. Contents written inside docker file
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
31. How about your experience developing CI/CD pipeline and utilizing tools such as Docker, Grafana and Prometheous. Share a particular project where these skills were critical.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
32. Multi stage docker build. In which scenarios it would be useful. Is is suitable for compile based language?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.

## Dockerfile — 13 questions

1. Sample Dockerfile question from the interview.
2. Write a sample multi-stage Dockerfile.
3. What are the stages in a Docker image build? Why do we use ENTRYPOINT and CMD instructions?
4. Explain how to write a dockerfile
5. Can you write a basic Dockerfile for your application?
6. How to write a multistage Dockerfile for a Node.js app — removing secrets and unnecessary layers?
7. What is a base image in a Dockerfile?
8. Can we write a Dockerfile without a base image?
9. R u using Dockerfile? u r build the dockerfile by codebuild?
10. Share your screen - write simple dockerfile
11. Docker cmd and entrypoint difference, how to configure sonarqube with azure
12. Difference between COPY and ADD commands in a Dockerfile.
13. difference between entrypoint and cmd in docker

## Images & Layers — 24 questions

1. Layers in Docker
2. Which container registry do you use for storing Docker images?
3. Are you aware of security scanning tools? How do you scan Docker images—both during build and at the registry level? Are you using any extensions or tools for image scanning?
4. How do you pass environment variables during Docker build commands? What services do you use for storing Docker images?
5. From where is the image pulled when you use docker pull image?
6. How do you reduce docker image size
7. What is difficulties you face while you build a docker image
8. How do you reduce the size of a Docker image?
9. What is a multi-stage Docker build? How does it help reduce image size?
10. What is Docker image layer caching?
11. How do you implement Docker image layer caching?
12. Do you use any tool for Docker image layer caching? If yes, which one?
13. How do you manage and version Docker images stored in Amazon ECR?
14. Explain Docker layer caching. During a Docker build, if layers 1–10 are already cached and you modify Layer 5, what happens to Layers 6–10? Will Docker reuse the cache or rebuild them? Explain why.
15. Explain me all the steps for multi stage docker image
16. What are the layer's you will get in Docker while building
17. What wil happen if the docker image has port 8080 and container/application has some port
18. How do you reduce the size of a Docker image?
19. Write the structure for building and pushing a Docker image for an application in GitHub Actions.
20. How do you check the integrity of a Docker image or file?
21. How were you authenticating Jenkins to push docker image to registery?
22. I want pass a value while building a docker image how can it be done?
23. If a Docker image becomes very large with many layers, what steps would you take to reduce its size?
24. image is there docker, I want to build an image, deploy to docker hub, tag it - commands in docker please

## Containers — 2 questions

1. Can we install docker inside a container.
2. If Docker containers are consuming too much disk space, how do you fix it?

## Networking — 2 questions

1. Types of networking in Docker and explain in detail
2. What is docker networking

## Volumes — 2 questions

1. Docker volume, docker prune
2. Difference between bind mounts and volumes in Docker.

## Registry — 0 questions

_No matching repository questions in the uploaded material._

## Security — 2 questions

1. How do you provide security in docker
2. Privileged mode in Docker. Explain with an example

## Production Scenarios — 1 questions

1. Can you explain Docker Compose and how it helps in multi-container application deployments?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Troubleshooting — 7 questions

1. There is issue with docker image due to its size, what are the action plans from you to reduce the size.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
2. You are unable to push docker image to dockerhub due to access issue. What are the sources where you can push your docker image other than dockerhub?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
3. How do you fix security issues in Docker images?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
4. Jenkins is failing to push a Docker image to the registry. How do you troubleshoot?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
5. If you have 10 layers in a Dockerfile and layer 6 fails, after fixing it, where will the rebuild start from and why?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
6. What is the issue with using large file image in dockerfile
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
7. Docker containers stopped suddenly after starting, how do you troubleshoot
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** container state → logs → image/tag → entrypoint/CMD → env/secrets → ports/network → mounts/permissions → resource limits
