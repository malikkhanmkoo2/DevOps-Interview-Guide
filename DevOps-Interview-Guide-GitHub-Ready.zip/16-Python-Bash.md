# 16. PYTHON / BASH

## Python Automation — 0 questions

_No matching repository questions in the uploaded material._

## Bash — 11 questions

1. Write a unix command to find out all the files which has a size more than 1 GB
2. Write a unix command to find the ERROR keyword in a txt file, ERROR will be incase sensitive
3. Write a shell script where you have one virtual machine ubuntu1, auto ssh enabled, ssh -i for private key, directory path /nobackup to be copied in another VM.
4. Linux Command to create softlink
5. Write a Bash script for log analysis.
6. Write a Bash script or command to get the total number of lines in a file.
7. Write a shell script to find and delete all files in a directory that are older than 30 days.
8. Write a shell script to sum (1..100) and give me result
9. Write a shell script that takes an integer N as input and prints numbers in a triangular pattern.
10. Write a shell script to delete the log files which is older than 30 days
11. How to assign and print a variable in Bash?

## File Operations — 0 questions

_No matching repository questions in the uploaded material._

## Process Automation — 0 questions

_No matching repository questions in the uploaded material._

## API Automation — 0 questions

_No matching repository questions in the uploaded material._

## Monitoring Scripts — 0 questions

_No matching repository questions in the uploaded material._

## Interview Coding — 14 questions

1. What is the difference between set and list in python(Counter question of the above)
2. Do you have any experience on python scripting
3. Python – Write a script to check disk usage and send an alert if it exceeds a threshold.
4. In Python, what are lists and tuples, and how do they differ?
5. What are decorators in Python?
6. Can you write code in Python? (Provided some samples)
7. Create a python script for this requirement
8. What is search keyword in Python?
9. What is the difference between shallow copy and deep copy in Python?
10. What are Lists and Tuples in Python?
11. If a Python program is failing due to memory issues, what can be the cause?
12. write python program for reverse a string
13. what is list and tuple in python
14. How does Python's GIL affect multi-threaded web service performance and what alternatives exist to overcome it? what is Python's GIL affect multi-threaded web service?
