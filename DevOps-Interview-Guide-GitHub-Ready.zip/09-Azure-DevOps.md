# 09. AZURE DEVOPS

## Pipelines — 9 questions

1. •    How do you integrate SonarQube & Snyk in Azure pipeline.
2. How to pass variable in azure pipeline? how to parameterize pipeline
3. How do you assess Azure DevOps migration readiness and plan the transition?
4. How would you use Azure DevOps REST API to apply a security policy to all repos programmatically?
5. [ ] What is the advantage of using a YAML file over classic build pipelines in Azure DevOps?
6. Difference between stakeholder and admin in azure devops
7. How the authentication and networking is established between azure devops pipeline and azure keyvault
8. How pipeline logs are stored in azure devops
9. Share your screen - write the structure of azure pipeline

## Variable Groups — 1 questions

1. Azure DevOps – Variable Groups, Environment Variables, and Secrets.

## Environment Variables — 0 questions

_No matching repository questions in the uploaded material._

## Secrets — 0 questions

_No matching repository questions in the uploaded material._

## Agents — 0 questions

_No matching repository questions in the uploaded material._

## Artifacts — 0 questions

_No matching repository questions in the uploaded material._

## Environments — 0 questions

_No matching repository questions in the uploaded material._

## Approvals — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 0 questions

_No matching repository questions in the uploaded material._
