# 14. GITOPS

## GitOps Fundamentals — 2 questions

1. What is argocd and why we are using it
2. what is Gitops

## Push vs Pull — 1 questions

1. GitOps – Push-based vs Pull-based deployment.

## Deployment Model — 1 questions

1. I want my deployment to be implemented to specific workloads or regions, that update shouldn't go to other parts. There is an option in argo CD

## Drift — 1 questions

1. How do you design GitOps for 1000+ clusters with environment drift detection, emergency hotfixes, and controlled manual overrides?

## Rollback — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._
