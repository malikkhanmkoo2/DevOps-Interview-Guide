# 01. LINUX

## Fundamentals — 15 questions

1. User password on modern linux location
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
2. Leap second in Linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
3. Booting in Linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
4. How to check load of linux machine
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
5. States of Linux machine
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
6. /proc purpose of this directory in Linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
7. stdin, stdout, stderr in linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
8. Diff between mount and directories in Linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
9. Disk I/O
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
10. Cron expression to schedule a job in Linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
11. In Linux, how do you attach and detach a filesystem?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
12. How do you print the last 15 lines of a file in Linux?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
13. linux"
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
14. Do you have experience with operating systems — Windows or Linux? What types of file permissions exist in Linux?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
15. Types of variables in linux
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.

## Commands — 5 questions

1. Best pick command to monitor disk write and reads
   - **Answer approach:** State the command, what it checks/changes, and what output you would inspect. Avoid listing commands without explaining the decision they support.
2. While rebooting a Linux machine, what are the stages / layers will be restarted
   - **Answer approach:** State the command, what it checks/changes, and what output you would inspect. Avoid listing commands without explaining the decision they support.
3. how will you troubleshoot if a system goes down in Linux - tell the commands
   - **Answer approach:** State the command, what it checks/changes, and what output you would inspect. Avoid listing commands without explaining the decision they support.
4. linux commands
   - **Answer approach:** State the command, what it checks/changes, and what output you would inspect. Avoid listing commands without explaining the decision they support.
5. how to find the mount point space of linux
   - **Answer approach:** State the command, what it checks/changes, and what output you would inspect. Avoid listing commands without explaining the decision they support.

## Process Management — 17 questions

1. How to check the linux process
2. How to kill the running process
3. Lack of memory on the web app server due to which it is failing to load the resources for the app
4. How to set a CPU and memory limit in Linux machine
5. Q4: now it is hosted and one of the services is leaking memory, how would you troubleshoot?
6. How do you handle disk, CPU alerts
7. What is meant by CPU throttling
8. Give a command to find a process and kill it.
9. what is zombie process
10. 0/5 nodes are available: insufficient memory.
11. If some developer hardcoded password mistakenly in source code and pushed to repo, how to fix it in CI process
12. Check CPU/memory usage?
13. 📈 Auto Scaling — Memory & Disk
14. Q5. How do you create auto scaling policies based on memory & disk usage?
15. How to check linux process without use of ps or top command
16. b) How to troubleshoot the issue and what will be checked during the process
17. ⁠explain the process how do you get request to create cloud resource s

## Networking — 6 questions

1. Write a script to monitor a directory and automatically copy any new files to a remote server using SCP.
2. What is Iptables in linux?
3. How to create a user without an SSH access
4. How you connect to private instances when the SSH connection is not working?
5. Create a script to monitor the disk usage of a server. If usage exceeds 80%, log the details to a file and send an alert email.
6. You’re locked out via SSH with no root access. How do you recover?

## Shell Scripting — 1 questions

1. How would you schedule a task to run every 15 minutes in windows using powershell and linux with cron?

## Production Scenarios — 3 questions

1. i have pub key and i want a dev to provide access to a server. where do u store pub key
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. How do servers get connected in Linux? explain.
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
3. how to do backup from ebs volume and attach in another server
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Troubleshooting — 3 questions

1. If you're unable to access linux machine, what you will do
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** CPU/load → memory/swap → disk/inodes → process/service state → filesystem permissions → network/socket/DNS → systemd/journal logs
2. If you're facing performance issues on a server, how do you troubleshoot?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** CPU/load → memory/swap → disk/inodes → process/service state → filesystem permissions → network/socket/DNS → systemd/journal logs
3. If there is a sudden spike in traffic on the server, how will you troubleshoot it?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** CPU/load → memory/swap → disk/inodes → process/service state → filesystem permissions → network/socket/DNS → systemd/journal logs
