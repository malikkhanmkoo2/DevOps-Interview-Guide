# 15. MONITORING / OBSERVABILITY

## Metrics — 7 questions

1. in webserver/app server which metrics is used to monitor the high availability
2. Where and How to check application performance metrics
3. During a Canary deployment, how would you verify that the 10% deployment is healthy? What metrics would you monitor before proceeding to 100%?
4. What kind of observability tools have you used, and what metrics have you been monitoring?
5. How would you get application level metrics
6. Metrics used for monitoring
7. Are memory and disk metrics available by default?

## Logs — 25 questions

1. Write a Python function that takes a list of dictionaries representing job logs. The function should return a list of job IDs where the "status" is "FAILED".
2. logs = [
3. If you're logging to linux machine for the first time, what will be the process
4. Question : Can you, talked about the dashboards of observability? Which are the observability framework tools That you're currently using?
5. If you’re not allowed to install Filebeat in your worker nodes for logging, then what will be possible option,
6. Kernel logs are stored under which directory
7. Database logs are not being written.
8. What proactive monitoring solutions have you implemented in your projects?
9. and monitoring?
10. What monitoring agents have you installed in your environment?
11. How do you perform infrastructure cost optimization using monitoring and observability tools?
12. How logs are segregated in ELK
13. Difference between observality and monitoring
14. diff between monitoring and observality
15. How do you set up monitoring and observability for ML models in production?
16. You are having lambda function and role everything setup perfectly but logs are not coming up in the cw group how to troubleshoot?
17. Explain about observability stack
18. Write a shell script that checks if a service is running, restarts it if not, and logs the event.
19. write a shell script to backup logs last 7 days and remove older days.
20. What logs do you check?
21. Slow query logs? Error logs? Performance Insights?
22. Check console logs?
23. Agent logs?
24. How can AI assist us in cloud infrastructure monitoring?
25. If credentials are visible in CI/CD pipeline logs, what will you do?

## Traces — 0 questions

_No matching repository questions in the uploaded material._

## Prometheus — 12 questions

1. What metrics do you monitor using Prometheus?
2. How to integrate grafana with prometheus
3. How do you configure Prometheus and Grafana for monitoring?
4. What is Prometheus, Grafana, Loki
5. How does Prometheus collect metrics
6. How is Prometheus setup
7. How do you setup Prometheus dashboard
8. How will you monitor the cluster through Prometheus
9. Prometheus memory is growing huge how do you debug this
10. did u configure Prometheus and Grafana?
11. About Prometheus/Grafana
12. Explain installation of prometheus and grafana..

## Grafana — 5 questions

1. What dashboards and alerts have you configured in Grafana?
2. grafana have you worked
3. What are data sources for Grafana, Kibana
4. How do you configure a Grafana dashboard?
5. How we monitor cpu matrics in grafana?

## Alerting — 6 questions

1. Question : What is your experience with alerts, logging, and incident/problem resolution?
2. Question : Have you used it in your day-to-day basis of dashboarding and alerting like based on the principles of SRE golden signals to set up alerts and dashboards?
3. Question : In Observability there is a concept of SLO based alerting. So have you configured that in your project?
4. What are the observibility needed for app —> Monitoring, Alerting, Logging, Remediation, PD,
5. Setup alerting for this setup
6. how the alert is created with which metrics when cpu and memory goes high in vm, what is action group, how do you create an  alert explain step by step etc, some basic troubleshooting kql queries in log analytics workspace - check on those things, any automation done with scripting etc for monitoring..

## SLI — 1 questions

1. What is SLI and SLO ?

## SLO — 2 questions

1. what is sla and slo
2. Question : Did all those things and have you kind of done anything like SLO based learning?

## SLA — 0 questions

_No matching repository questions in the uploaded material._

## Incident Response — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 0 questions

_No matching repository questions in the uploaded material._
