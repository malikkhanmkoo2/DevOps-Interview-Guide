# 02. GIT / GITHUB

## Fundamentals — 25 questions

1. what is the differences between git pull and git fetch?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
2. write down GIT commands which you use on daily basis and explain the cmds
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
3. I have localcopy of repository and I did some changes to one file and want to push the changes to remote repository. what are the git commands you would run
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
4. Write a checkout stage with Git credentials.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
5. Diff between git fetch and git pull (what happens in background in depth)
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
6. What happens behind the hood when git add command is provided. File is added but what happens in the background how git knows on this command it has to add file. ( in dept related to git database)
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
7. Git sqash
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
8. How deployment is done in different environment using git repo
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
9. what is git checkout
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
10. In Git, explain the push and pull commands.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
11. What is the use of Git tags?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
12. Write a GitHub/GitLab pipeline to deploy a microservice with 3 services running in parallel.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
13. How do you set up GitHub runners for the application environment?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
14. Follow-up for Q23: If you are using GitHub Marketplace actions, which are third-party tools, how do you ensure security concerns regarding them?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
15. What is the difference between git push --force-with-lease vs --force?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
16. How can you delete the last 2 git commits?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
17. In GitHub, after a code commit, what validations do you perform? Do you validate before the commit or after the commit?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
18. How do you extract all git commits from last 3 days?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
19. Git submodules, what is their purpose
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
20. GitLab / CI-CD Questions
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
21. Have you worked on GitLab?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
22. Can you tell me what are rules in GitLab?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
23. diff between github repo and jfrog
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
24. 10 developers are checking in code in GIT, I want to remove the code checkin done by developer 10, how to do that ?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
25. difference between git fetch and git pull
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.

## Branching & Merging — 9 questions

1. Explain your Git branching strategy. How do you deploy code from different branches to different environments?
2. What is git branching strategy used in your organisation
3. Explain git branching startgey
4. Explain git branching startgey
5. What are the different types of branches in Git?
6. What iare ur git branching strategies
7. What type of GitHub branching strategy are you using? Please explain.
8. Git branching strategy?
9. What is Git and why we are using it and what is branching strategy

## Advanced Git — 9 questions

1. what is mean by git stash and pop?
2. Brief me about GIT Stash
3. Explain the difference between Git Merge and Git Rebase.
4. Git rebase
5. What is Git Rebase?
6. What is the difference between Git Merge and Git Rebase?
7. Explain Git Merge and Git Rebase with an example using the main and feature (or master) branches.
8. What’s the difference between Git Merge and Rebase?
9. Git stash

## Git Workflows — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 3 questions

1. How to handle merge conflict in git. If 2 people working on same file and did the commit and got conflict err, in how many ways it can be solved (someone explain pls).
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** working tree/status → branch/remote → commit history → merge/rebase conflict → reflog for recovery → permissions/credentials → CI status
2. How will you resolve the git conflict automatically?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** working tree/status → branch/remote → commit history → merge/rebase conflict → reflog for recovery → permissions/credentials → CI status
3. what is git merge conflict
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** working tree/status → branch/remote → commit history → merge/rebase conflict → reflog for recovery → permissions/credentials → CI status
