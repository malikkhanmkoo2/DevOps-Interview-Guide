# 08. AZURE

## Azure Fundamentals — 9 questions

1. Set up an Azure Bastion Host for secure access to the VMs
2. Configure an Azure Load Balancer to route traffic to the application VMs
3. Hi Can anyone explain me best explanation on diffrenec between azure managed identity and service proncipal , how to explain this in tnterview
4. Why Dynamic blocks are used in tf and write the skeleton for an azure resource using dynamic block
5. What is azure board, what are the things inside it
6. How will you store credentials in azure pipelines
7. What are the different types of subscriptions in azure
8. How will you implement dc/dr in azure – which are the services you will be using it
9. What is azure artifact

## VMs — 0 questions

_No matching repository questions in the uploaded material._

## VNet — 3 questions

1. Define an Azure Virtual Network (VNet) with a given IP range
2. How will you refer the output of vnet module based subnetid as an input to the VM module
3. Types of vnet peering

## IAM / RBAC — 0 questions

_No matching repository questions in the uploaded material._

## AKS — 10 questions

1. •    How do you use Azure Key vault's secrets in AKS?
2. •    How do you secure your AKS cluster?
3. •    How do you make your AKS cluster highly available.
4. •    How do you perform cost optimization in AKS.
5. •    How do you do you integrate And  EntraID with your AKS for authentication?
6. Logs are incomplete — how would you troubleshoot across AKS, Ingress, App, and Infra?
7. How will you provide access to only one pod/app to a storage account and restrict all the other pods within AKS
8. Out of 32 GB memory AKS cluster, 30 GB is already utilized, Whether a new pod with request 500mb and resource limit of 4Gi can be scheduled in the same cluster using HPA/VPA
9. what is the networking you are using in AKS
10. How to troubleshoot if pod is failed in AKS, commands please

## Storage — 3 questions

1. Recommended tools for CI/CD, artifact storage, vulnerability scanning, and container registry in a hybrid (on-prem + Azure) setup?
2. Elaborate the pipeline steps to move a file from azure blob to gcp cloud storage(automated way)
3. What are the different types of azure storage

## Azure Monitor — 2 questions

1. How to monitor Azure VM memory and alert if it crosses 80%?
2. How to set alerts in azure monitor (explain steps and configuration that u do)

## Key Vault — 5 questions

1. How mysql will interact with azure key vault and it should happen thru privately and should not go anything on public
2. [ ] Do you have experience using Azure Key Vault?
3. [ ] Have you integrated Azure Key Vault into your pipelines or branches in any project?
4. [ ] Did you create the Azure Key Vault access policies yourself, or did someone else do it for you?
5. How azure key vault is integrated in cicd

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 0 questions

_No matching repository questions in the uploaded material._
