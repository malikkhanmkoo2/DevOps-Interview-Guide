# 17. NETWORKING

## OSI / TCP-IP — 7 questions

1. IPv4 vs IPv6
2. IPv4 address starts from
3. Write a script to find out if the provided IP is valid IPv4 or not
4. OSI models ?
5. Explain about OSI model,
6. what is ipv4 and ipv6
7. Explain OSI models

## DNS — 11 questions

1. what is dns
2. Do nslookup for dns resolution if that works fine
3. AAA and CNAME in DNS
4. Fail over mechanism in DNS (if one IP is not reachable)
5. What is difference between coreDNS and kube-proxy.
6. How would you setup DNS here?
7. what happens when youe hit DNS from browser
8. Purpose of DNS in your project.
9. Have you created DNS record?
10. DNS Custom resolver
11. suppose you are having an ecs task definition, I have an website , the developer is hitting the url or website, what will be the flow of traffic , fargate is a serverless – how do you achieve configuration DNS or website over there

## HTTP / HTTPS — 7 questions

1. How to provide HTTPS access to an application hosted in a private subnet.
2. What is Az App Gateway and how it encrypt http/https traffic
3. HTTP request header and HTTP Methods,
4. How will you restart http service from VM
5. difference between http and https
6. Suppose we configured a load balancer but it’s not accepting HTTPS request what would you do?
7. Without installing certificate how would you divert the traffic coming from http to https

## TCP / UDP — 1 questions

1. what is tcp and udp

## Ports — 3 questions

1. Container port: 80
2. Can you avoid the specific port traffic using SGs?
3. Difference between cluster ip and node port?

## Load Balancing — 0 questions

_No matching repository questions in the uploaded material._

## Proxy — 5 questions

1. How does kube-proxy communicates with nodes
2. Reverse proxy
3. Reverse proxy and forward proxy
4. How would reverse proxy setup work here?
5. What is reverse proxy

## Firewall — 3 questions

1. How to check the firewall protection
2. What is WAF (Web Application Firewall) and AAF (Application Access Firewall)?
3. What is Web Application Firewall,

## Connectivity Scenarios — 45 questions

1. Configure Network Interfaces (NICs) and attach them to the correct subnets
2. Is it possible to create NAT gateway in private subnet ?
3. You need to connect your DB running in private subnet, not using NAT gateway or NAT instance or bastion host, what are the other options,
4. Diff b/w Public and Private subnet
5. How to connect your private subnet with Internet
6. Does NAT gateway will run in public or private subnet
7. Which network will be used to isolate a communication b/w two containers
8. What is mean by Nat Gateway and Nat instance?
9. Ping/telnet won't make sense since networking side is fine
10. Difference between nat gateway and internet gateway
11. How you will direct traffic to and from a instance in private subnet
12. What is the difference between NAT Gateway and IGW?
13. That we can extend the subnet CIDR once it is created?
14. Once you create that subnet, the instance will get created, but will it be able to communicate with the old instances?
15. For all VPCs, will you configure the Transit Gateway attachment with CIDR range?
16. Two VPCs need to communicate, but their CIDR ranges overlap. Transit Gateway is not allowed. What alternative solution would you recommend?
17. How private subnet connect with outside world
18. What is the purpose of NAT gateway
19. How to desgin an web appl handle flucting low latency and how traffice flow in it
20. How to achieve low latency routing? Which routing you will use?
21. Difference between NAT gateway and NAT instance.
22. I can able to get access application from outside container but from inside getting packet loss. How do you trobleshoot.
23. How to restrict the communication between them ? → network policy
24. What component should be added in network policy YAML file
25. What are Network ACLs and Security Groups, and how do they differ?
26. Tell me the flow of network packets starting from user hit the application url
27. What is NAT gateway?
28. What are NACLs,SecurityGroups,NAT Gateway
29. What happens when an user hits "www.clarify.com" how the request pass through the network ?? write a diagram and explain it to me
30. Explain amazon traffic architecture how it goes to private subnet? I write diagram and explained it
31. Public and Private Subnet, what makes it public and private??
32. What is subnet?
33. I have webapp in India and slowly users from abroad are also tyring to access it but there is latency. How would fix this issue, which service can help in reducing latency?
34. If developer sets private subnet to public, what should you do?
35. Why are you keeping your web application in a public subnet?
36. Can you tell me the difference between NAT Gateway and Internet Gateway?
37. Explain the complete request flow when using Gateway API with multiple GatewayClasses across regions. How do you prevent split-brain routing?
38. What happens internally when etcd latency spikes above 500ms? How does it impact the scheduler, controllers, and API server?
39. Is target response latency high?
40. CPU? Memory? Latency? IOPS? Connections? Disk queue depth?
41. Does IP X fall in CIDR Y?
42. How to calculate whether an IP is inside a CIDR block?
43. ⁠diff bet Nat gateway and igw
44. ⁠where does route table is placed (private subnet of private subnet)
45. In terms of Cost optimisation which one should we use, Az App gateway or network gateway?

## Troubleshooting — 0 questions

_No matching repository questions in the uploaded material._
