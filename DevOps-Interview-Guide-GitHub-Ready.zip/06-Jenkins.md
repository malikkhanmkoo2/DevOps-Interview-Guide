# 06. JENKINS

## Fundamentals — 29 questions

1. How do you perform complete backup up of Jenkins including jobs/configurations/authentications
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
2. CI/CD & Jenkins
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
3. How would you implement dynamic stages in a Jenkinsfile based on environment variables?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
4. What are shared libraries in Jenkins, and how are they written and defined?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
5. How do you use Jenkins shared libraries? Explain their typical structure and how they are integrated into your Jenkinsfiles.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
6. Have you worked on Jenkins as your CI/CD tool, or used others like GitLab?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
7. How do you manage concurrent builds in Jenkins and ensure performance doesn’t degrade?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
8. Explain if a standalone Jenkins server setup will work, and what to consider.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
9. filled — how do you manage this in Jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
10. How can you reduce the build time in jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
11. How can you trigger an automatic build in jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
12. Write Jenkins script to trigger simultaneous/ parallel execution.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
13. What is Jenkins, Ansible
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
14. different plugins for ci/cd in jenkins using aws platform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
15. Jenkins vs GitHub Actions.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
16. jenkinsfile stages
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
17. What is the difference between Continuous Delivery and Continuous Deployment, and how do you implement them in Jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
18. How do you perform complete backup up of Jenkins including jobs/configurations/authentications,
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
19. how do you copy the jobs from one jenkins worker node to another worker node
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
20. how do setup the communication between jenkins and kuberenetes
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
21. Which type of Jenkins File u r using? Can u pls Write a Jenkins File?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
22. what you did with Jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
23. How are you integrating the SonarQube with the Jenkins server?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
24. How did you integrate SonarQube with Jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
25. What things have you done in Jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
26. How do you store sensitive information like passwords in jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
27. Why do you want to use Argo CD over Jenkins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
28. What type of Jenkins job is best?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
29. Q17. If a Jenkins job starts but gets stuck, how do you debug?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.

## Pipeline — 19 questions

1. Write your jenkins pipeline
2. what are the ways to trigger the pipeline in Jenkins
3. How do you call variables in a Jenkins pipeline?
4. How would trigger pipeline B in jenkins automatically after pipeline B
5. Explain how you would set up a multi-branch Jenkins pipeline for a GitHub repository.
6. Explain the CI/CD workflow you follow and the kind of pipeline you use. How do you define and invoke pipelines in Jenkins?
7. What kind of applications do you deploy using Jenkins pipelines, and what deployment tools do you use?
8. Describe your typical deployment flow and CI/CD workflow. What stages do you define in your Jenkins pipeline, and how do you ensure full quality checks during deployment?
9. Show a sample Jenkins CI/CD pipeline code.
10. How many ways can you trigger a Jenkins pipeline?
11. How to integrate azure key vault in jenkins / azure pipeline
12. What are the different type of Jenkins pipeline?
13. How do you deploy python application on aws using jenkins pipeline
14. What if I have 10 FE micro services and 10 BE micro services how do you design the cicd pipeline using jenkins?
15. Write your jenkins pipeline,
16. what are the ways to trigger the pipeline in Jenkins,
17. How does authentication happen in Jenkins pipeline to use aws with particular login, if you have 1 logout?
18. I want jenkins run pipeline once n number of commits are pushed how will you do that.
19. How will you secure your jenkins pipelines.

## Declarative Pipeline — 0 questions

_No matching repository questions in the uploaded material._

## Scripted Pipeline — 0 questions

_No matching repository questions in the uploaded material._

## Agents — 2 questions

1. What is a Jenkins agent?
2. What is a Jenkins agent?

## Credentials — 1 questions

1. How do you manage credentials in Jenkins?

## Webhooks — 0 questions

_No matching repository questions in the uploaded material._

## Artifacts — 0 questions

_No matching repository questions in the uploaded material._

## Nexus / Artifactory — 1 questions

1. In a Jenkins pipeline, at which stage would you publish or push artifacts/images to Nexus or Artifactory—pre-build, build, or post-build? Why?

## Distributed Builds — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 8 questions

1. Multibranch pipeline in Jenkins: How to configure it What problems it solves Why it is preferred over a normal SCM pipeline.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
2. If the Jenkins pipeline runs but the build doesn’t happen, what possible issues could be causing it?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
3. Have you faced any memory issue in Jenkins pipeline? how would you troubleshoot
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
4. If we have 5 stages in a jenkins pipeline and 5th stage having syntax error then what will happen if we run the pipeline.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
5. Your aws jenkins pipeline takes high time, how will you troubleshoot
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
6. Jenkins – If the controller (master) node goes down, how will you troubleshoot and restore it?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
7. Your CI/CD pipeline has failed in jenkins. How do you investigate?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
8. Jenkins pipeline deployment failed in production but working in Dev, how do you troubleshoot and fix the issues.
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** queue/executor → agent connectivity → console log → credentials → SCM/webhook → workspace → artifact repository → controller/resource health
