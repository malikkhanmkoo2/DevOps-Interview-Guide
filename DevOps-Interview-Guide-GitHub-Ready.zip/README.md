# DevOps Interview Guide — 5-Year Preparation

A tool-wise DevOps interview preparation guide built from the interview material in this repository.

The original repository contains real interview write-ups organized company-wise. This version reorganizes the captured interview questions by **tool/topic** so preparation is easier. The repository currently describes 151 interview write-ups across 85 companies and topics including Kubernetes, Docker, Terraform, AWS/Azure/GCP, CI/CD, Ansible, Linux, scripting and SRE fundamentals. 

## How to use this repository

For each technology:

1. **Fundamentals** — understand the concept.
2. **Commands / hands-on** — practice it in a lab.
3. **Production scenarios** — explain how you would use it in a real environment.
4. **Troubleshooting** — explain your investigation path, evidence, mitigation and verification.
5. **Architecture / SRE** — practice designing reliable production systems.

## Tool-wise guide

| # | Topic | Guide |
|---|---|---|
| 01 | Linux | [01-Linux.md](./01-Linux.md) |
| 02 | Git / GitHub | [02-Git-GitHub.md](./02-Git-GitHub.md) |
| 03 | Docker | [03-Docker.md](./03-Docker.md) |
| 04 | Kubernetes | [04-Kubernetes.md](./04-Kubernetes.md) |
| 05 | Terraform | [05-Terraform.md](./05-Terraform.md) |
| 06 | Jenkins | [06-Jenkins.md](./06-Jenkins.md) |
| 07 | AWS | [07-AWS.md](./07-AWS.md) |
| 08 | Azure | [08-Azure.md](./08-Azure.md) |
| 09 | Azure DevOps | [09-Azure-DevOps.md](./09-Azure-DevOps.md) |
| 10 | Ansible | [10-Ansible.md](./10-Ansible.md) |
| 11 | CI/CD | [11-CI-CD.md](./11-CI-CD.md) |
| 12 | GitHub Actions | [12-GitHub-Actions.md](./12-GitHub-Actions.md) |
| 13 | Helm | [13-Helm.md](./13-Helm.md) |
| 14 | GitOps | [14-GitOps.md](./14-GitOps.md) |
| 15 | Monitoring / Observability | [15-Monitoring-Observability.md](./15-Monitoring-Observability.md) |
| 16 | Python / Bash | [16-Python-Bash.md](./16-Python-Bash.md) |
| 17 | Networking | [17-Networking.md](./17-Networking.md) |
| 18 | SRE / Production | [18-SRE-Production.md](./18-SRE-Production.md) |

## Interview answer framework

For a normal concept question:

**Definition → Why → How it works → Production example → Trade-offs**

For a scenario:

**Impact → Scope → Recent changes → Evidence → Isolation → Mitigation → Verification → Prevention**

For troubleshooting:

**Symptom → Health/status → Logs/events → Resources → Network/dependencies → Mitigation → Verification → RCA**

## Important

The questions in the tool-wise files are based on the uploaded interview repository. The answer frameworks and troubleshooting checklists are preparation guidance added around those questions; they are not presented as original interview-source text.

## Recommended preparation order

**Linux → Git → Docker → Networking → AWS/Azure → Terraform → Jenkins/CI-CD → Kubernetes → Helm → GitOps → Monitoring/Observability → SRE/Production**

For a 5-year DevOps interview, prioritize **scenario-based troubleshooting, production architecture, incident handling and explaining why you choose a particular approach**, not just definitions.
