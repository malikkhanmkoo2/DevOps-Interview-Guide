# 11. CI/CD

## CI vs CD — 33 questions

1. What is CICD and explain in briefly
2. What is the purpose of a webhook, and how is it used in a CI/CD pipeline?
3. Explain your complete CI/CD pipeline from code commit to production deployment.
4. Where do you store CI/CD secrets such as pipeline credentials?
5. Explain your end-to-end CI/CD pipeline in your current project
6. Explain a simple CI/CD pipeline in short.
7. Q1: lets say our app is nodejs app how wd u setup cicd pipeline
8. and which ci/cd tools would you use?
9. What are the tools you have used for CI/CD pipeline?
10. 12 .How do you handle parallel execution in CI/CD workflows?
11. Where do you store application credentials in your CI/CD pipeline?
12. Explain an end-to-end CI/CD pipeline.
13. [ ] You mentioned improving CI/CD efficiency by 60%. Can you explain the specific optimizations you made for this?
14. explain CI/CD pipeline
15. How would you set up entire CI/CD setup for this application
16. What kind of CI/CD pipelines are you familiar with?
17. What ci/cd do u use tell us about it in detail
18. Whats ur organisation current cicd process and tools
19. What securities measures/tools u were taken in ur cicd pipeline?
20. Whats ur organisation current cicd process and tools
21. How do you prioritize and manage multiple critical issues in a CI/CD pipeline failure?,
22. Explain how you build CICD pipeline..
23. Explain flow of CI/CD pipeline
24. With respect to DevOps, to set the CI/CD pipeline, which tools and services have you used?
25. 🔄 CI/CD
26. Q20. What CI/CD tools have you worked with?
27. Q16. Have you integrated SonarQube in your CI/CD pipeline?
28. What is CICD?
29. Any challenges have you faced in CI/CD in your team, Tell me about it. How did you overcome this?
30. All the questions are scenario-based and counter questions. - I have remembered these question , all the counter questions into CICD related and Kubernets.
31. ⁠explain you cicd pipeline
32. ⁠what are policies you used for cicd pipeline
33. How do you write in yaml to create a ci/cd pipeline from scratch to test and deploy from Dev to UAT

## Pipeline Design — 2 questions

1. New application scenario:Developer has written only source code As a DevOps engineer, how to design CI/CD...Deploying to DEV / QA / PROD using best practices.
2. How do you design and implement a complete CI/CD pipeline for ML models?

## Pipeline Stages — 7 questions

1. Various stages of CI/CD
2. Mostly he have asked me CI/CD in depth and write the stages in detailed.
3. Explain CI/CD pipeline and its stages
4. How to schedule pipeline, lets say i have validated the pipeline with some update and i want to schedule it to stage/main branch, how to do? (This also someone explain)
5. Explain the pre-build, build, and post-build stages in a CI/CD pipeline.
6. What is the command or pipeline syntax used to refer the variable output of the previous stage in the current stage
7. Do you use pipeline for three different env or one for all? Explain how?write a groovy script using any ci cd took for build, test and deploy stages.

## Artifacts — 1 questions

1. Difference between build artificats and pipeline artifacts and which one is better

## Deployment Strategies — 0 questions

_No matching repository questions in the uploaded material._

## Blue-Green — 11 questions

1. Explain Rolling Update, Blue-Green, and Canary deployment strategies.
2. How do you implement blue-green deployment in your project?
3. What is blue green deployment explain a project based on it
4. Why canary and blue green differ
5. So how are you implementing the blue green deployment?
6. Canary vs blue green
7. Can we perform Blue Green deployment under the same namespace? If yes, how will you manage them?
8. Once the blue green deployment is completed, how to check if the deployment is successful.
9. If you're going with Blue Green deployment, how will you change your configuration to reroute the traffic between blue and green, exactly which configuration needs to changed?
10. Purpose of Blue Green deployment and how will you switch back to diff deployments ?
11. Explain Blue-Green deployment.

## Canary — 2 questions

1. Suppose you are implementing a Canary deployment where only 10% of users receive the new version. How would you implement it through your CI/CD pipeline?
2. What is Rolling Strategy and Canary-based deployment?

## Rolling Deployment — 0 questions

_No matching repository questions in the uploaded material._

## Rollback — 8 questions

1. How do you connect to two databases, and how do you ensure rollback during exceptions?
2. CI/CD pipeline needs rollback capability. How would you implement it?
3. Describe how you handled a rollback situation during a major release. What went wrong, and what did you learn?,
4. ⚙️ CI/CD — Branch-Based & Rollback
5. Q15. Have you ever set up rollback in CI/CD?
6. How do you implement automatic rollback?
7. What triggers a rollback?
8. If a rollback fails, how will you handle it?

## Production Scenarios — 32 questions

1. What is the purpose of agent, post-conditions and environment blocks in pipeline
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. How did you reduce a pipeline from 1 hour to 20 minutes?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
3. How you integrate SonarQube to your pipeline
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
4. For a mission-critical production application, which deployment strategy would you choose and why?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
5. Explain what an application pipeline is.
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
6. Where do you write the code/yaml file for pipeline
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
7. What are the advantages of multibranch pipeline?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
8. What are some main differences between scripted and declarative pipeline.
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
9. If the pipeline fails due to existing resources, how do you handle RIP (Remove, Import, Plan)?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
10. Pipeline fails only on Tuesdays, no code changes — how do you debug?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
11. Explain Continuous Integration, Continuous Delivery, and Continuous Deployment.
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
12. Difference between Continuous Delivery and Continuous Deployment.
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
13. [ ] What is a recent challenge you faced while implementing a DevOps practice or pipeline in your team or organization?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
14. CI-CD pipeline in details
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
15. What is runs-on in a pipeline? Which type of runners are you using in your organization, and do you know how to configure self-hosted runners?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
16. How do you trigger a pipeline if:
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
17. How is static code analysis configured in your pipeline file?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
18. What if developer coming to you and saying that remove code quality from the pipeline as it is slow in scanning the code in this scenario what steps would you take?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
19. What is the purpose of agent, post-conditions and environment blocks in pipeline,
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
20. If a pipeline is deleted by one of your team member, how would you recreate and how would you prevent this scenario in future
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
21. How you will build single or minimal reusuable pipeline templates for 50 different applications
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
22. What do u know about Cyberark and what and how u r consuming that in ur pipeline
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
23. Have you ever dealt with a security vulnerability in your DevOps pipeline? How did you detect and respond to it?,
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
24. there is data in ADF, data will not be constant always, it will be dynamic how do you get the data and analyse it and present (it can be done through pipeline too)
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
25. Separate pipelines or single pipeline?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
26. Should pipeline constantly “check” repo?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
27. How to implement TF in CD pipeline
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
28. If a CI pipeline is taking 45 minutes to run, how can you optimize it?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
29. What is the role of continuous integration?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
30. What types of pipeline you use. How many types of pipeline are there
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
31. What is variable in pipeline
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
32. If we have to run multiple jobs parallely using a single pipeline, can it be done? How?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
