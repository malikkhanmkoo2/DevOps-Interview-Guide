# 10. ANSIBLE

## Fundamentals — 14 questions

1. How can you install a patch through ansible in more than 20 servers?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
2. What is your hands-on experience with Ansible? Explain a real project where you used it.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
3. Any expercience on ansible?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
4. ansible file in writen
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
5. What is the difference between import and include in Ansible?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
6. In ansible if you need to execute something as root user how do you that?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
7. Block, release_on in Ansible
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
8. Ansible command to view log during execution
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
9. what is ansible tower
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
10. what is ansible tower
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
11. What is Ansible Tower?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
12. What does idempotent mean in Ansible?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
13. How does Ansible work?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
14. I have a senerio to deploy an application on 100 servers using Ansible, how do you perform it.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.

## Inventory — 0 questions

_No matching repository questions in the uploaded material._

## Playbooks — 7 questions

1. Write a playbook to deploy an Nginx server and ensure the service is started and enabled on boot. How would you manage secrets in Ansible?
2. write a playbook to install apache in VM?
3. how to run anisble playbook and diff options
4. How do you write an Ansible playbook, and what client requirements do you consider?
5. Ansible playbook times out on one host out of twenty. What do you check?
6. If you have two different VMs,, how will you modify your playbook for diff requirement?
7. What is an Ansible Playbook?

## Modules — 4 questions

1. module used to install nginx web server when automating using ansible in new server
2. ansible module u useto ensure specific package is installed on a new websrrver while configuring the server
3. ansible module u useto ensure specific package is installed on a new websrrver while configuring the server
4. what are the ansible modules you have used

## Variables — 1 questions

1. and how to manage variables diff env in ansible

## Roles — 7 questions

1. what is ansible roles
2. what is ansible roles
3. What is an Ansible Role?
4. What is an Ansible Role, and how do you create it?
5. What is an Ansible Role, and how do you create it?
6. Describe the structure and advantage of using an Ansible role to manage a three-tier web application. what do you mean by three-tier web application?
7. if you have custom plugins that multiple roles depends on, how do you manage them in the context of Ansible Roles Management?

## Templates — 0 questions

_No matching repository questions in the uploaded material._

## Vault — 1 questions

1. what is ansible vault

## Terraform + Ansible — 0 questions

_No matching repository questions in the uploaded material._

## Production Scenarios — 0 questions

_No matching repository questions in the uploaded material._

## Troubleshooting — 0 questions

_No matching repository questions in the uploaded material._
