# 07. AWS

## EC2 — 41 questions

1. Application is hosted on a public EC2 instance.How to migrate it to a private subnet following AWS best practices (security, networking, HA).
2. Sending log files from EC2 to S3, what are the steps ?
3. I need to send a logs from EC2 to S3, create an automation part where we need to take the log file, check the CPU metrics and send an alarm through cloud watch to user's.
4. Write a python script to list the EC2 instances running in your cloud which has the tag of PROD,
5. You have been tasked to create 20 EC2 per account and you been provided with 10 AWS accounts, so totally you need to create 200 EC2 machines, how will connect all these machines. Which service will be used?,
6. what metrics is used to monitor ec2 instance cpu, memory in aws
7. You have an EC2 instance and you would like to migrate it from one region to another. How will you do it?
8. How did you set up ECS using EC2 instances?
9. Web application is not accessible but ec2 is running fine.what are the major reasons
10. I want to take data of how many ec2 running and how many EBS are attached from 50 or 60 aws accounts without logging into individual account . How can we do that
11. EC2 in a private subnet should receive inbound traffic, how to enable it ? → NOT NAT Gateway
12. userdata in EC2
13. ASG is active and the load is heavy, due to that two EC2 instances are launched, but EC2 provision is taking 2 to 3 mins of time because of the ASG terminating the instance, how to avoid it.
14. Which AWS EC2 instance types have you used, and why did you choose them?
15. Apart from using password, how to login to EC2
16. EC2 has IAM roles, what all things can we explore from it ✅ (aws)
17. I have EC2 and S3 in same subnet, region how to access that bucket from instance ✅ (aws)
18. I have EC2 instance, internet connectivity not there, how to tackle this ❌ (aws)
19. Manually EC2 updated from t3.medium to t3.large manually and updated the code and committed but pipeline not ran. If you run pipeline then what will happen? (nothing will happen – code is in local machine of devops) ✅ (aws)
20. In my ec2 2 containers are running backend and frontend so i wanto connect my backend container to rds service how
21. how to connect S3 with ec2 if a script generates files daily that need to be pushed S3.
22. Types of ec2 instance.
23. You are able to launch an EC2 instance from the AWS Console, but you cannot SSH into the instance. How would you install tree package
24. Explain EC2 instances and handling multiple VPCs.
25. When to  use Ec2 and when to use Lambda.. give scenario based answers
26. then what you do if ec2 has comprised, I have given the answer of making the permissions as deny all then terminating ec2 if not needed
27. about IAM/Fargate/EC2/Lambda?
28. What are the security parameters we must consider while we are creating an EC2 instance for production?
29. I have created an EC2 instance named A, and I want to create another instance B. It should create an instance without deleting instance A. What can I do during this?
30. Two AWS accounts are there in same organisation. Account A has Ec2 instance and Account B has some tokens.  Need to access the tokens from Ec2 instance.
31. How do you login to the ec2 instance if you've lost the .pem key?
32. If I have EC2 instance for which I don’t want to talk to internet but intra-communication can be possible, how to configure it?
33. Say you need to configure EC2 instances automatically or replace themselves automatically when they fail. How do you implement this?
34. Say you have EC2 instances running web servers and need deployment with minimal downtime during updates. How do you approach this?
35. EC2?
36. Q2. Create an EC2 IAM role that allows access only to S3 + DynamoDB and denies access to all other services.
37. How will you make sure EC2 is not deleted while running destroy command.
38. How do you restrict a user to only EC2 and RDS access?
39. If someone manually changed the EC2 config, which was created through TF, how to fix it ?
40. Other ways to connect EC2 without pem key
41. A developer asking Ec2 instance for his local deployment, how you will achieve and what type of instance you create and give it to them.

## VPC — 32 questions

1. Does Amazon S3 require a VPC?
2. Like you have to deploy, you have to basically create VPC and map you have to create a subnet and you have to attach let's be the public or a private submit. It's of your choice to attach it to your VPC.
3. How to connect a VPC in AWS to VPC in IBM Cloud
4. Difference between subnet and nacl
5. How would you set up networking in vpc
6. Because you are telling it from the IAM perspective, what about the VPC?
7. How does VPC Peering work?
8. If we connect VPCs to the Transit Gateway, what will you update in the VPC Route Table?
9. What is VPC Flow Logs and how will you track the IPs hitting the VPC?
10. Purpose of using VPC Endpoint with use case
11. How to segregate the critical details from VPC flow logs
12. Can we create two diff CICR blocks 172. && 192. series in same VPC
13. If you're storing all your VPC Flow logs in S3 bucket, how to see that
14. If the RDS is in a private subnet, how do you access it securely without using public tools like MySQL
15. Difference between Transit gateway and VPC,
16. Public and private subnet is there, NAT gateway is attached to private subnet what is use of that (masking of private ip) ✅ (vpc)
17. How does NAT gateway protect my private subnet, what concept does it use to secure the resource (same masking) = masking is protecting the private subnet ✅ (vpc)
18. Difference between transit gateway and vpc peering.
19. VPC
20. how to access s3 from vpc securely
21. what is VPC peering.
22. What is major vpc difference between aws & gcp vpcs?
23. What vpc connect?
24. Can you tell about your VPC structure and networking architecture used in your project?
25. Do you manage VPC/subnets/security groups?
26. Which VPC/subnet configuration did you use?
27. VPC?
28. Q4. Two apps in same VPC → each behind a public ALB → if App A calls App B, how does traffic flow?
29. What stays inside VPC vs what leaves?
30. 🌐 VPC & Networking
31. Q9. Request comes from Internet → enters VPC through IGW → what is the first security layer? NACL or SG?
32. When you create a VPC, what default components are added?

## IAM — 17 questions

1. You have created an IAM user in AWS and configured role-based access in EKS. How do you bind the IAM user to the EKS role?
2. Assume you have 10 AWS accounts. How will you securely log in to them, considering access keys are not used for security reasons?
3. How do you set up RBAC in Amazon EKS?
4. I’m an admin but I don’t have access to the S3 bucket ? → IAM permission boundary
5. I have multiple IAM user which is best approach: 1. attach policy individual to user OR 2. add that user to group and attach policy ✅ (iam)
6. Inline policy or attaching policy which is right approach ❌ (iam)
7. How do you ensure the least privilege access to the IAM users
8. what all the types of polices we have in iam
9. so list the usrs who  has not accessed the keys in iam for more than 90 days
10. delete the inline policy for users where *  is mentioned in the iam users list
11. diff between IAM Users and Roles
12. So how many types of policy, IAM policy are there? IAM policies?
13. Say if you have both explicit deny and allow policy to a user in AWS IAM, what happens?
14. Can you tell me the difference between managed policy and inline policy in IAM?
15. What IAM policy do you attach?
16. IAM?
17. 🔐 IAM & Policies

## S3 — 27 questions

1. You have an S3 bucket at us-south-1, is it possible to access that bucket from us-east-1 ?
2. what is mean by CRR in s3?
3. How do you update the statefile from local to S3 bucket,what will you do if it gets lost.
4. If a user wants to access the S3 bucket, what are the processes?
5. If you are storing logs in S3 Bucket, how will you track that particular IP?
6. Apart from storing TF log files in S3, do we have any other options
7. S3 lifecycle rules – what is the advantage of using them ✅ (s3)
8. How to design an event-driven architecture using S3, Lambda, and SNS for data ingestion
9. Q8: How would you store secure info inside s3?
10. Types of storages…difference between s3 and EBS.
11. Create a terrsform state file s3 bucket which expires within 30 days
12. What are s3 bucket lifecycle policies?
13. Explain on Lambda, CFT, Data Storage, S3 ?
14. What is the purpose of creating S3 bucket policies?
15. How do you maintain the lifecycle of an S3 bucket?
16. How to host an S3 static website without enabling public Access
17. So what is the difference between the S3 bucket policies and acls?
18. An S3 bucket was made public by mistake. How do you secure and audit it?
19. What are the different type of S3 storages available?
20. How to spead up s3 upload with files in large size,  and client uploaded 10 Gb file but failed  after uploading 5 gb how you confirm that 5 gb is uploaded to s3
21. how do you make s3 secure  which is  have client sensitive  data
22. Do you manage S3 lifecycle policies?
23. S3?
24. 🪣 S3 — Lifecycle + Versioning
25. What is ACM and S3 ?
26. Difference between S3 and EBS
27. ⁠explain command to use s3 native lock

## EKS — 37 questions

1. If secrets are created in AWS Secrets Manager, how can Amazon EKS access those secrets?
2. how would you maintain high availability in ecs + fargate or eks
3. What are the node groups you used in AWS EKS?
4. What are the types of node groups in AWS EKS?
5. How do you manage and connect services like DBs, EC2, EKS, or ECS? Include the command to connect to ECS.
6. How do you handle authentication for EKS clusters and store secrets securely in your environment?
7. What will you do for zero-downtime when eks cluster upgrade
8. Diff b/w Fargate vs EKS worker nodes
9. Updating EKS cluster
10. how to upgrade eks clusetr
11. what are steps to upgrade eks cluster
12. A Jenkins pipeline is randomly failing at the deployment stage to EKS. Logs show timeouts during kubectl apply.
13. What issues did you face with EKS Cluster?
14. What to do when the etcd from EKS goes down?
15. In my EKS cluster 2 node groups are there before deploying pods , node group -2 is showing unhealthy why ? I do have all the permission to check, how to troubleshoot and step to avoid such situations on future.
16. If your application is on EKS how the traffic flows if user hits the URL.
17. What is the primary difference between ECS and EKS?
18. How do you upgrade your eks
19. When would prefer on-prem Kubernetes cluster over EKS and vice-versa
20. EKS cluster upgrade entire process
21. "Route 53", and "EKS and DB Automation and Administration"
22. What is the difference between EKS vs ECS vs Fargate?
23. If you are given a project eg EC2 or EKS or anything else what are the things you would take into consideration from prerequisite till output?
24. What is ECS & EKS and when would you choose either of it?
25. How do you scale EKS? What are the metrics considered and where do you add your inputs and How? Explain how you have done auto-scaling in your project
26. In which subnet are you placing your EKS cluster and which networking components have you used?
27. Do you create EC2/EKS/ECS resources?
28. Q3. On which compute platform are the applications hosted? (Expected: EKS)
29. Why EKS over ECS?
30. ☸️ EKS & Kubernetes
31. Q4. Have you created an EKS cluster? Explain the process.
32. Q5. Have you upgraded an EKS cluster before? How?
33. Q12. How to implement shared storage across multiple pods running on multiple nodes in EKS?
34. How do you deploy to EKS through GitHub Actions?
35. Can you deploy mongo db database in EKS cluster. If yes how and what all configuration things you would need to keep in mind
36. Argo CD. How do you manage CI/CD in your organisation. How many EKS clusters you manage, no of nodes
37. Want to create a module for EKS cluster. What would be the structure

## Load Balancer — 12 questions

1. Diff b/w ALB and NLB in depth
2. What is mean by Sticky session in ALB?
3. Howmany Loadbalancers avaialble in AWS and explain each one
4. what is the difference between alb and nlb, in which scenario you use alb and nlb
5. Diff b/w ALB and NLB
6. ALB and NLB have you used it ✅ (aws)
7. What are ALB and NLB, and when should you use each one?
8. difference between ALB and ELB and comes under which layer, when  to choose and why
9. how autoscaing happens with ALB
10. Do you know cost of ALB vs private ALB?
11. 🔁 ALB Cross-Communication
12. Which option is costlier, public or private ALB?

## Auto Scaling — 1 questions

1. Have you worked on AWS Auto Scaling?

## RDS — 16 questions

1. Can you tell me the difference between secondary RDS and read-only RDS?
2. So have you built the RDS of your own or you have managed it only?
3. You have RDS and tomorrow, I being your client, will tell you that you need to make the configuration in such a way so that only one user can access the RDS at a time. How will you configure that?
4. Like where I will set up the RDS, is it?
5. To upgrade the version of DB in RDS, suppose you have 7.0 MySQL installed, and you want to upgrade it into 8.0 and above. What is the process?
6. How do you configure AWS RDS, and what factors do you consider (size, requirements, etc.)?
7. How much data is stored in your RDS MySQL?
8. How many masters and slaves are in RDS?
9. How do you provide rds ready only access to developer
10. What if production rds is growing 95% how do you debug and how do you prevent this in future
11. RDS migration with minimal downtime – how would you approach it?
12. Can you tell me the difference between traditional RDS and Aurora?
13. RDS?
14. Q7. App is slow → you suspect RDS. What do you check?
15. Q8. You found memory pressure on RDS. You cannot resize. What immediate action can you take without downtime?
16. Horizontal and vertical scaling RDS db steps

## CloudWatch — 7 questions

1. How to filter a particular IP from AWS CloudWatch Log Group?
2. In CloudWatch, what is the use of log groups and log trails?
3. Cloud watch & how do you create a custom metric in AWS CloudWatch.
4. CloudWatch?
5. Why do we need CloudWatch Agent?
6. Where do you create CloudWatch alarms?
7. Explain the AWS architecture shown in the diagram (CodePipeline, CodeBuild, CodeDeploy, CloudFormation, CloudWatch).

## Route53 — 5 questions

1. Can't we configure Route 53?
2. If we want to configure third-party domains like GoDaddy in Route 53, how do we do that?
3. What is Route 53?
4. In Route 53, can you tell me the difference between A record and CNAME record (written as “ad code and symmetry code” in screenshot)?
5. Use of Route53

## Security Groups / NACL — 10 questions

1. Discussion around ALB/NLB, ACM certificates, routing, and security groups.
2. what is the difference between NACL and Security groups?
3. Check if any firewall/security group rules are blocking the flow of traffic
4. Difference between sG and NACL
5. What is difference between NACL & security groups
6. If we have security group configured in the instance do we really need nacl.,
7. What is security group and what is the default traffic rule in sg
8. What is the difference between Security groups and NACL?
9. Why NACL first?
10. Q10. If NACL denies a CIDR, but SG allows same IP, can the IP access LB?

## Production Architecture — 82 questions

1. What are the ways to log in to an AWS account?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. If you’re migrating a monolithic application from on-prem to Cloud and the system has its local file system, which file system you will use in AWS.,
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
3. Onboarded trading app into AWS, how will you make sure availability, scalability, security,
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
4. what are the different types of triggers in lambda aws?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
5. Difference between elasticIP and publicIP in AWS
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
6. which are all the services you used in AWS
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
7. design an high availability, fault tolerance system in aws
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
8. What types of nodes did you deploy in AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
9. What is the difference between AWS Config and AWS CloudTrail?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
10. How do you take the backup of AWS Services?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
11. Can we create AWS backup using Shell Scripting?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
12. How do you create AWS Lambda functions and manage the artifacts for deployment? What options do you use to push artifacts to Lambda?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
13. How to check LB health details (monitoring) through AWS service
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
14. TGW in AWS
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
15. AWS Image builder
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
16. Give a real-world use case of AWS Lambda.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
17. A developer accidentally commits AWS credentials to Git. What is your complete incident response process?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
18. I attended interview for devops role, they were asking very basic questions about devops & aws.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
19. What is AWS Lambda and how do you design a serverless application?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
20. Account 1 to Account 2 – send AMI but its KMS encrypted, help me do that ❌ (aws)
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
21. Two instances are there what is the best way to communicate with them, create new NIC or attach ❌ (aws)
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
22. KMS, Secrets Manager have you worked on it ❌ (aws)
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
23. Q5: out of aws and azure what would u choose and why?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
24. How to make connections between on prem to AWS suppose if we want to share files from on prem.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
25. What is OIDC provider in AWS.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
26. How do you deploy an application to AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
27. What is serverless in AWS, and how are you using it?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
28. How are you provisioning your AWS services?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
29. How do you optimize cold starts in AWS Lambda ?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
30. What is Serverless deployment in AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
31. How to handle cost optimization in aws…how can we plan for cost optimization.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
32. How are you connecting client's environment from your AWS environment.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
33. security best pracices in aws
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
34. how to manages certificate in aws. If the certificate expires how are you managing it and what's the action you are taking over here.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
35. Suppose you joined to a organisation, how the access would be given to you.how to secure aws account as admin.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
36. aws lambda where to use use case
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
37. service to monitor spike in aws .application cpu usuage in cloud.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
38. Apart from SageMaker, which AWS or open-source services have you used or are aware of for training ML models?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
39. How do you prevent misuse or unauthorized usage if someone attempts to spin up ML services in AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
40. What strategies do you use to optimize and control AWS costs for ML workloads?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
41. How do you manage AWS + Azure using a single DevOps process with focus on security & cost?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
42. [ ] Other than Azure and AWS, are you familiar with any other cloud platforms or services?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
43. How do I transfer payloads between lambda function in 2 different AWS account
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
44. AWS Cloud Engineer role -:
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
45. How do you did cost optimization in AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
46. How do you implement best security policies on AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
47. How comfortable with AWS and how much rate urself out of 5?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
48. How do you scan the vulnerabilities specially for AWS instances.
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
49. How can you protect the data in an AWS instance?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
50. How can you connect from AWS to on-prem servers?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
51. Suppose in your DevOps team, new team members are added to your team. How can you provide AWS access to your new users, what is the behavior of login to the console?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
52. What are the services u were used in AWS
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
53. Have you worked on the AWS, right?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
54. Design a highly available backend on AWS – what services and architecture would you use?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
55. What are the AWS resources you have used in your previous role?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
56. If there is a vendor who provides VPN services for company A, his manager wants to view some dashboard but do not have AWS account. How would you help him?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
57. What is AWS lambda and where have u used?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
58. Do you have experience with AWS DevOps services like CodeDeploy, CodeBuild, and CodePipeline? How would you set up a pipeline using them?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
59. ELB inflow and outflow
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
60. How do you secure your environments in aws
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
61. Your aws billing spikes, what should you check
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
62. In AWS, what all the services you have used?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
63. How many AWS storage services does it have?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
64. AWS Questions
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
65. What are the AWS services that you have worked on?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
66. How do you retrieve secrets from AWS Secrets Manager using Python?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
67. How do you encrypt secrets in AWS Secrets Manager?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
68. Is everything on AWS or multi-cloud?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
69. ☁️ AWS Cloud Responsibilities
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
70. Q2. What exactly do you do in AWS Cloud in this project?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
71. Where is aws-auth stored?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
72. Do you use AWS Secrets Manager?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
73. ☁️ AWS & Cloud Concepts
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
74. ☁️ AWS Hands-On Services (Round 2)
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
75. Q1. Which AWS services do you have the most hands-on experience with?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
76. What types of nodes did you deploy on AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
77. What is the difference between Interface Endpoint and Gateway Endpoint in AWS?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
78. How do you restrict access to AWS resources for a specific user?
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
79. AWS CDK commands
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
80. AWS secret manager vs parameter store
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
81. AWS billing increased suddenly, how do you identify the costs
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
82. In AWS how do you configure subdomains (like godady/bigrock)
   - **Answer approach:** Start with requirements and failure domains, then design for availability, security, scalability, observability, backup/DR, deployment and rollback.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Troubleshooting — 5 questions

1. You want to create an EC2, and while creating the instance, you are getting an error like IP address exceeded. How will you troubleshoot and fix it?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** IAM → security group/NACL → route tables → DNS → load balancer target health → instance/system logs → CloudWatch metrics/logs → service quotas/dependencies
2. EC2 instance is unreachable, and it’s not a security group issue. What’s your next step?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** IAM → security group/NACL → route tables → DNS → load balancer target health → instance/system logs → CloudWatch metrics/logs → service quotas/dependencies
3. If RDS is hosted in us-west region and has read replicas spread across other region, due to some issue us-west region is down, how will you redirect your traffic. But having one more DB is expensive to the client
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** IAM → security group/NACL → route tables → DNS → load balancer target health → instance/system logs → CloudWatch metrics/logs → service quotas/dependencies
4. 🧮 RDS Troubleshooting
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** IAM → security group/NACL → route tables → DNS → load balancer target health → instance/system logs → CloudWatch metrics/logs → service quotas/dependencies
5. Application on AWS EC2 behind the loadbalancer suddenly unavailable, how do you troubleshoot
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** IAM → security group/NACL → route tables → DNS → load balancer target health → instance/system logs → CloudWatch metrics/logs → service quotas/dependencies
