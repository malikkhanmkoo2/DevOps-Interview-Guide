# 05. TERRAFORM

## Fundamentals — 94 questions

1. What happen when we run terraform init ?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
2. Coding Task (Terraform on Azure):
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
3. Question : So how you are using terraform to deploy the cluster nodes?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
4. Write a Terraform code to create VPC, subnet, EC2, S3 bucket.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
5. You created couple of resources using Terraform, how will you make sure that resources are not modified through UI, how will you automate this check
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
6. what is the use of command terraform fmt?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
7. writedown the few terraform commands and explain each cmd
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
8. terraform structure
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
9. Suppose you have created an EC2 instance by logging into the AWS console. And now you would like to manage it using Terraform. How shall you do it?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
10. …resources in Terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
11. Write Terraform code to provision an EC2 instance with a security group allowing only SSH access.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
12. Terraform scripts for creating AWS services Jenkinsfile EKS and On Prem Kubernetes cluster upgrade steps.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
13. How do you create and manage Kubernetes clusters (using tools like Terraform), and what are the master and worker nodes?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
14. Write a Terraform configuration file for ec2 with EBS volume attached
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
15. What is your Terraform file structure for vpc, eks
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
16. What is the Terraform init and Terraform refresh
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
17. Terraform:
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
18. Do you execute Terraform locally or through a CI/CD pipeline? Explain the complete workflow.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
19. Terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
20. What is the difference between terraform plan and terraform apply?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
21. What AWS resources have you created using Terraform and how do you promote a read replica to primary using Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
22. In Terraform, which parameter or code change is needed to make a read replica the primary?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
23. What are best practices to be followed on terraform,
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
24. terraform have you build the vm
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
25. Can you use same build spec used in AWS CodeBuild ✅ (terraform)
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
26. Q7: diff b/w terraform, cloudformation and arm and what would u prefer?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
27. Write a terraform script to create EKS Cluster.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
28. What is Terraform and how do you use terraform in your project and what all resources have you provisioned
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
29. Why terraform is used
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
30. For example, if someone modifies a security group in Terraform and opens it to 0.0.0.0/0, what mechanisms can we use in Terraform to stop such changes from being applied?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
31. How you are creating different environment in terraform.(dev,prod,test)
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
32. terraform provisioner
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
33. How will you connect your terraform environment from aws and implement CI/CD.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
34. What is terraform work space and how are you managing it.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
35. If we have created 3 instances using terraform script and the instance names are mentioned as a list
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
36. How do you set up infrastructure for deploying ML models using Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
37. Tech stack— mainly around Terraform, Azure, DevOps, Docker, and Git
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
38. How do you scale a Terraform pipeline that takes 25+ mins?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
39. How do you export Azure resources into Terraform code?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
40. How do you enforce Azure Policies (like tag or location restrictions) using Terraform at scale?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
41. Terraform – Difference between terraform refresh and terraform plan.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
42. Terraform vs Ansible – When to use each and how they work together.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
43. In Terraform, how would you create multiple EC2 instances, each with different configurations (for example, different instance types, AMIs, tags, or volumes)?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
44. [ ] Are you familiar with Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
45. [ ] Can you describe a real-time scenario where you used Terraform to provision a highly scalable infrastructure?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
46. what is difference between content and tuple in terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
47. what is diffrence between list and string in terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
48. What are the terraform lifecycle policies
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
49. Why do we use workspace in terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
50. What is terraform external command and when it should be used
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
51. How do you ensure particular AMI image is present in AWS account using terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
52. What are terraform provisioners
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
53. What is meta-arguments in terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
54. Project specific questions(How would you setup a new environment on AWS, Terraform code provisioning)
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
55. How are you provisioning infra using terraform via CI/CD
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
56. In Terraform, what is the purpose of init, plan, and apply commands?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
57. What CICD is using in your project for terraform infrastructure.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
58. Difference between Iam users.. GitHub Oidc role and terraform io role.. which is secured and when to use use GitHub Oidc and when to use terraform io role
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
59. Write a terraform code to provision an Ec2
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
60. then cloudformation and terraform differences
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
61. least privileage in cft for the stacks and terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
62. Can u pls write terraform file to provision the Ec2 instance in a public subnet in a VPC?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
63. What are the provisioners available in Terraform and can you explain the use cases?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
64. What is the difference between a map of objects in Terraform and how can you write an example?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
65. About Ansible,Terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
66. Write a Terraform code to create multiple S3 buckets
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
67. Terraform script to provision an EC2 instance with a custom security group and user data script.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
68. Explain terraform move command?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
69. How can you handle terraform different environments?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
70. Terraform taint
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
71. How to enable Debug logs in Terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
72. Terraform Questions
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
73. Have you worked on Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
74. Say I created an S3 bucket using Terraform and want to modify the bucket name. Is it possible? How would you do this?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
75. How do you handle multiple environments in Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
76. If I want to start an ec2 instance once the cpu is utilised 80% what terraform code will you write and it also should copy the image from S3.
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
77. Explain how Terraform handles dependency graphs internally. How can circular dependencies still appear in real projects?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
78. How would you manage Terraform when multiple teams deploy to the same AWS account but must not overwrite each other’s resources?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
79. Did you use console, CLI, or Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
80. 🧱 Terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
81. Q23. Have you used Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
82. 🧱 Terraform Advanced
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
83. Q18. Terraform generated RDS password, you didn’t save it. Can you retrieve it?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
84. Where does Terraform store generated values?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
85. What to do if a terraform apply takes too much time?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
86. If something is created on the cloud platform and it is not present in Terraform, how will you achieve it?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
87. Terraform apply is creating all the resources again. What can be the possible problem?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
88. You need to create 50 instances in one go. How will you create them in Terraform?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
89. suppose there are multiple ec2 instances manually created via console, I have to update those ec2 instances via terraform, what is the command
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
90. difference between cloud formation and terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
91. Could you elaborate your experience with automating and optimizing the deployment over large infrastructure using AWS and other tools like Terraform and Ansible from your previous roles?
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
92. They were mainly looking for terraform and Aws experience
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
93. What commands you know in terraform
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.
94. ⁠did you come across a scenario where you used terraform destroy
   - **Answer approach:** Answer in this order: definition → why it exists → how it works → practical example → key limitation.

## Providers — 9 questions

1. write a terraform script to create an ec2 instance in multiple region.
2. You have defined a multi-region Terraform configuration (region1, region2, region3). If you create an EC2 instance, in which region will it be deployed?
3. Question : Set up the nodes and everything. what do you write inside a terraform code basically now what will be inside your provider file provided ATF in your main dotf?
4. Question : I'll give you an example like let's talk about AWS. You have you're going to create a VPC and subnet And your provider is AWS and I'm asking you to write in using terraform.
5. what is mean by Provisioner and provider in terraform?
6. Can the same Terraform code be used for different cloud providers?
7. How will you implement multi region Terraform code
8. Write Terraform code to create an AWS EC2 instance and include variables for instance_type and region.
9. If you want to deploy EC2 instances in 3 different region what would the terraform code structure look like

## Resources — 5 questions

1. 4 write sample terraform resource file
2. If someone deleted a resource in terraform how can you identify it and recover it. how to detect some one deleted in tf how to rectifty
3. Terraform provisioned resource should not delete by deleteing resource configuration in terraform code how can you do it?
4. You created a resource through Terraform but it failed during provision, what will happen
5. Purpose of using "null resource" in Terraform

## Variables — 1 questions

1. Diff between local and variable in Terraform,

## Outputs — 0 questions

_No matching repository questions in the uploaded material._

## Modules — 9 questions

1. Draw and explain your Terraform repository structure. How do your dev, qa, and prod environments consume shared modules like the VPC module?
2. How will you write terraform module for EKS.
3. What are the terraform modules you use
4. What are modules in Terraform?
5. What are modules in Terraform?
6. Q19. Do you know what a custom Terraform module is?
7. what is module in terraform
8. ⁠explain your terraform modules
9. I have made some changes in the module for one resource, the resource should get updated but it should not get destroyed and recreated again when we do terraform apply. How would you approach

## State — 19 questions

1. what is the terraform statefile
2. What happens if the Terraform state becomes corrupted, and how would you recover from it?
3. What happens if tfstate file gets deleted,
4. Terraform tf.state file is deleted  how to recover it( conditions: it was not sync with s3 or any vcs to take a backup)
5. What happens to the Terraform state file if someone deletes resources from Azure?
6. What happens if the Terraform state file is accidentally deleted?
7. terraform state file locking
8. How do you manage the state file in terraform and where do you store it?
9. I have created an EC2 instance through Terraform. I don't have a backup of the Terraform state file, it is not in the remote state and locally not available. Now when I do apply, what can I do?
10. What is terraform state mv?
11. Explain terraform statefile
12. Is it possible to move terraform state file to remote configuration once created?
13. Explain Terraform state file –
14. In which file you will define where Terraform state file should be generated and where it has to be maintained (which config file)?
15. How do you safely refactor a Terraform monorepo with hundredsgg of state files into a module-based architecture without downtime?
16. What is a Terraform state file interpreter?
17. If somebody has deleted the Terraform state file locally, what can be done?
18. what is the terraform command for unlock statefile
19. How do you implement state locking in terraform

## Remote Backend — 2 questions

1. How would you migrate a Terraform backend from local to a remote backend like S3 with DynamoDB locking?
2. 2 Instances are created using terraform. Statefile is located locally and also in remote backend(S3). If a user deletes 1 instance what would happen? How would you handle this?

## Workspaces — 0 questions

_No matching repository questions in the uploaded material._

## for_each / count — 1 questions

1. For each in terraform. Explain with an example

## Import — 3 questions

1. Question : How do you import a resource into Terraform that was created manually in AWS or GCP? What command would you use?
2. what is the the use of terraform import ?
3. If we can use terraform import for existing AWS resources which are not created by Terraform, then what is the use of data source?

## Drift — 3 questions

1. Two engineers are working on the same Terraform code. How do you prevent conflicts and handle Terraform state locking or drift?
2. What is terraform drift command
3. What is Terraform drift?

## Production Scenarios — 2 questions

1. Which components or resources are required to create a 3-tier architecture using Terraform?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.
2. Explain to me Terraform architecture ?
   - **Answer approach:** Use: clarify impact → check recent changes → establish scope → inspect metrics/logs/events → isolate the failing layer → mitigate → validate → RCA/prevention.
   - **Interview structure:** impact → scope → evidence → isolation → mitigation → verification → prevention.

## Troubleshooting — 6 questions

1. What is terraform lock hcl file,
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** init/provider → validate/plan → state/backend/lock → drift → dependency graph → credentials/permissions → module/input changes → safe apply/recovery
2. terraform uses real time issue we faced…what are the error u faced in terraform recently
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** init/provider → validate/plan → state/backend/lock → drift → dependency graph → credentials/permissions → module/input changes → safe apply/recovery
3. Terraform has errors while provisioning infrastructure. How to do investigate those? Basically how do you validate the terraform file
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** init/provider → validate/plan → state/backend/lock → drift → dependency graph → credentials/permissions → module/input changes → safe apply/recovery
4. If terraform deployment got failed, what will be the approach
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** init/provider → validate/plan → state/backend/lock → drift → dependency graph → credentials/permissions → module/input changes → safe apply/recovery
5. Can you tell me what is Data Block in Terraform?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** init/provider → validate/plan → state/backend/lock → drift → dependency graph → credentials/permissions → module/input changes → safe apply/recovery
6. Describe a production failure caused by terraform apply. What guardrails would you implement to prevent it permanently?
   - **Answer approach:** Use a layered approach: symptom → scope → recent change → health/status → logs/events → resource/network/dependency checks → mitigation → verification → RCA.
   - **Investigation checklist:** init/provider → validate/plan → state/backend/lock → drift → dependency graph → credentials/permissions → module/input changes → safe apply/recovery
